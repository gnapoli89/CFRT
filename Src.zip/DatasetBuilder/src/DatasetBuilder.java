
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.NoSuchElementException;

import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.util.JSON;
import com.sun.org.apache.bcel.internal.generic.NEW;

import org.bson.Document;
import org.bson.conversions.Bson;



public class DatasetBuilder {

	private static String dbName = "test";

	public static void main(String[] args) {

		//open client
		MongoClient mongoClient = new MongoClient("localhost", 27017);
		//set db
		MongoDatabase mydb = mongoClient.getDatabase(dbName);

		System.out.println("retrieving data from data");


		//set collection -data-
		MongoCollection<Document> dataCollection = mydb.getCollection("data");

		//get AVG response time values 
		FindIterable<Document> iterable = dataCollection.find(new Document("Type", "average_response_time")).sort(new Document("Time", 1));
		Iterator<Document> it = iterable.iterator();
		ArrayList<Double> avgResTime = new ArrayList<Double>();
		while(it.hasNext()){
			Document doc = it.next();
			avgResTime.add(doc.getDouble("Value"));
		}

		//get number of simultaneous connections values 
		iterable = dataCollection.find(new Document("Type", "number_simultaneous_connections")).sort(new Document("Time", 1));
		it = iterable.iterator();
		ArrayList<Double> numSimConn = new ArrayList<Double>();
		while(it.hasNext()){
			numSimConn.add(it.next().getDouble("Value"));
		}

		iterable = dataCollection.find(new Document("Type", "hourly_uptime_percentage")).sort(new Document("Time", 1));
		it = iterable.iterator();
		ArrayList<Double> hup = new ArrayList<Double>();
		while(it.hasNext()){
			hup.add(it.next().getDouble("Value"));
		}


		System.out.println("retrieving data from logs");
		//prendere il time minimo per poi verificare se ci sono state violazioni negli intervalli di 5 minuti
		//set collection -log-
		MongoCollection<Document> logCollection = mydb.getCollection("log");
		iterable = logCollection.find().sort(new Document("Time", 1)).limit(1);
		it = iterable.iterator();
		Long minTime = it.next().getLong("Time");

		Long time0 = minTime; 
		Long time1 = minTime+300000; //5 mins

		ArrayList<String> atkList = new ArrayList<String>();

		for(int i=0; i<288 ;i++) { //288 is the number of 5min interval in 1 day

			DBObject dbObject = (DBObject) JSON.parse("{$and: [{Time: {$gte : "+time0+"}}, {Time:{$lte : "+time1+"}}]}");	
			time0 = time1; 
			time1 = time1+300000; //5 mins

			iterable = logCollection.find((Bson) dbObject);						
			it = iterable.iterator();

			boolean found = false;
			while(it.hasNext()){
				if(it.next().getString("URI").contains("?atk=1")){
					atkList.add("A");
					found = true;
					break;
				}
			}
			if(!found){
				atkList.add("B");
			}
			found = false;
		}


		System.out.println("retrieving data from violations");
		//set collection -violations-
		MongoCollection<Document> violationsCollection = mydb.getCollection("violations");
		time0 = minTime; 
		time1 = minTime+300000; //5 mins
		ArrayList<String> violationList = new ArrayList<String>();
		for(int i=0; i<288 ;i++) { //288 is the number of 5min interval in 1 day

			DBObject dbObject = (DBObject) JSON.parse("{$and: [{Time: {$gte : "+time0+"}}, {Time:{$lte : "+time1+"}}]}");	
			time0 = time1; 
			time1 = time1+300000; //5 mins

			iterable = violationsCollection.find((Bson) dbObject);						
			it = iterable.iterator();
			try{
				System.out.println(it.next().toJson()+ "at interval i:"+i);
				violationList.add("1");
			}catch(NoSuchElementException e){
				violationList.add("0");
			}
		}



		mongoClient.close();



		System.out.println("writing CSV");
		//write data on dataset file
		BufferedWriter bw = null;
		try {
			bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("Dataset.csv")));

			bw.append("id;simconn;restime;hup;violation;attack\n");
			//for cicla per 1 ora
			//for cicla per 5 minuti
			//for cicla per 1 minuto -- fai la media
			//for(int i=0;i<hup.size();i++){
			for(int i=0;i<24;i++){ //24 ore
				for(int j=i*12;j<i*12+12 && j<avgResTime.size();j++){
					/*					double connAvg = 0;
						for(int k=j*5;k<j*5+5 && k<numSimConn.size();k++){
							connAvg = connAvg + numSimConn.get(k);
						}
						connAvg = connAvg/5;
					 */
					try {
						//						bw.append(connAvg+";"+avgResTime.get(j)+";"+hup.get(i)+"\n");
						bw.append(j+";"+numSimConn.get(j)+";"+avgResTime.get(j)+";"+hup.get(i)+";"+violationList.get(j)+";"+ ""+atkList.get(j)+"\n");
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						try {
							bw.close();
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
				}

			}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			if(bw!=null)
				try {
					bw.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}





		System.out.println("Finished! (dataset.csv file can be found in the same folder of DataserBuilder.jar)");
	}

}
