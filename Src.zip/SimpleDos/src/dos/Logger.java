package dos;

import java.sql.Timestamp;
import java.util.Date;

public class Logger {
	
	public static void write(String info){
		java.util.Date date= new java.util.Date();
		System.out.println(new Timestamp(date.getTime()) + " "+ info);
	}
}
