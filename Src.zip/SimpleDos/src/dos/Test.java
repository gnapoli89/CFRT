package dos;

public class Test {

	public static String TEST_FILE = "file1";
	public static int ATTACKER_VAR = 0; //MALICIOUS?
	public static int REQUESTTIME_VAR = 5; //client buono, fa richiesta ogni 5 sec
	public static Beans HASHMAPS = new Beans();
	public static int ATTACK_LENGHT = 1000*60*5; //5 MINUTI
	public static int ATTACK_BETWEEN = 1000*60*120; //120 MIN 
	public static String TOMCAT_BASE_PATH="/usr/share/tomcat7";


	public static void main(String[] args) {

		if(args.length > 0){
			if(args.length < 4){
				if(args[0].equals("--help")){
					System.out.println("params: http://server_address port_number base_uri MALICIOUS_MODE");
					return;
				}
				System.out.println(args[0]+ "Missing arguments. --help to see arguments needed.");
				return;
			}
			
			Test.ATTACKER_VAR = Integer.parseInt(args[3]); //switch the mode
			
			if(Test.ATTACKER_VAR == 2){ //HC mode
				HealthChecker hc = new HealthChecker(args[0], Integer.parseInt(args[1]), args[2]);
				hc.run();
				
			}else{ //Attacker - Client mode
				DOSClient dosClient = new DOSClient(args[0], Integer.parseInt(args[1]), args[2]);
				dosClient.setDelay(REQUESTTIME_VAR*1000); 
				System.out.println("Connecting...");
				dosClient.run();
			}
		}
		else{
			System.out.println("Missing arguments. --help to see arguments needed.");
		}
	}
}

