package dos;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.HashMap;

public class Beans {

	private HashMap<Integer,String> filesToPut;
	private HashMap<Integer,String> filesToGet;
	
	public Beans(){
		filesToPut = new HashMap<Integer, String>();
		this.initialize();
		filesToGet = new HashMap<Integer, String>();
	}

	private void initialize() {
		String name = "file";
		int fileNum = 10;
		for(int i=0; i<10; i++){
			this.executeCommand("dd if=/dev/urandom of="+name+i+" bs="+i*1024*1024*10+" count=1");
			filesToPut.put(i, name+i);
		}
	}

	public HashMap<Integer,String> getFilesToPut() {
		return filesToPut;
	}

	public HashMap<Integer,String> getFilesToGet() {
		return filesToGet;
	}
	
	public String executeCommand(String command) {

	    StringBuffer output = new StringBuffer();

	    Process p;
	    try {
	        p = Runtime.getRuntime().exec(command);
	        p.waitFor();
	        BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));

	        String line = "";           
	        while ((line = reader.readLine())!= null) {
	            output.append(line + " ");
	        }

	    } catch (Exception e) {
	        e.printStackTrace();
	    }

	    return output.toString();

	}
	
	

	
}
