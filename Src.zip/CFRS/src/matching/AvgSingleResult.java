package matching;

import java.util.concurrent.Callable;

import logs.AWSDictionary;
import logs.ObjectHolder;
import net.sourceforge.jeval.EvaluationException;
import net.sourceforge.jeval.Evaluator;

/** Average function invoked if in an avg function other formulas are present
 * 
 * 
 *
 */
public class AvgSingleResult implements Callable<String>{

	String formula;
	String result;
	Evaluator evaluator;
	double period;
	private long limInf;
	private long limSup;
	private String unit;

	
    /**
     * 
     * @param evaluator: an JEval evaluator
     * @param formula: formula in avg function
     * @param periodDouble: SLO period expressed in double 
     * @param unit: unit of measure of SLO parameter
     */
	public AvgSingleResult(Evaluator evaluator, String formula, double periodDouble,String unit){
		this.formula = formula;
		this.evaluator = evaluator;
		result = null;
		this.period = periodDouble;
		this.unit=unit;
		limInf = ObjectHolder.timeInf[0];
		limSup = ObjectHolder.timeSup[0];
	}

	/**
	 * Calculates formula value in the period
	 * 
	 *  @return: a string containing inner formula result
	 */
	public String call() throws InterruptedException {
		int index=0;
		int index1=0;

		if(limInf < 0 || limSup < 0){
			//limInf = Calendar.getInstance().getTimeInMillis();
			ObjectHolder.timeInf[0] = limInf = Long.parseLong(ObjectHolder.db.getMin("Time").get("Time").toString());
			ObjectHolder.timeSup[0] = limSup = ObjectHolder.timeInf[0]+(int)period*60000;
		}else{
			ObjectHolder.timeInf[0] = limInf = limSup;
			ObjectHolder.timeSup[0] = limSup = limInf+(int)period*60000;
		}


		
		String atom;
		Long value;
		String newFormula = formula;
		while(index>=0){
			index=newFormula.indexOf("[",index+1);
			index1=newFormula.indexOf("]",index+1);
			if(index<0)
				break;
			atom = newFormula.substring(index+1,index1);
			String atomtrim=atom.trim();
			//System.out.println(atomtrim);
			
			//set parameters of interval of time into Dictionary
			while(AWSDictionary.in_use){
				Thread.sleep(1000);
			}
			ObjectHolder.dictionary.setlimInf(limInf);
			ObjectHolder.dictionary.setlimSup(limSup);
			//System.out.println(ObjectHolder.dictionary.translate(atomtrim));
			value = ObjectHolder.db.count(ObjectHolder.dictionary.translate(atomtrim));
			//System.out.println("atomtrim: "+atomtrim+ "value: "+value);
			newFormula = newFormula.replace("["+atom+"]", Long.toString(value));

		}
		try {
			result = evaluator.evaluate(newFormula.replace("'", ""));
			if(result.equals("NaN")){
				result = "0.0";
			}
			if(result.equals("Infinity")){
				result = "0.0";
			}
			if(unit.equals("%")){
				return ""+Double.parseDouble(result)*100;
			}
			else{
				return result;
			}
		} catch (EvaluationException e) {
			e.printStackTrace();
			return null;
		}

	}


}
