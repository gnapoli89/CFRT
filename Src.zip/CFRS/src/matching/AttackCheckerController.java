package matching;


import GATE.SLA;
/**
 * Thread that launch all the AttackChecker if the attack is possible
 * 
 *
 */

public class AttackCheckerController implements Runnable{

	SLA sla;
	public AttackCheckerController(SLA s){
		sla=s;
	}
    /** Invoke and start one or more AttackChecker if SLO that compose the attack are present
     * 
     */

	public void run(){
		AttackChecker attack;
		if(sla.hasSLO("uptime") && sla.hasSLO("averageResponseTime") && sla.hasSLO("numberOfConnections")){
			attack=new DDoSChecker(sla);
			new Thread (attack).start();
		}
	}

}




