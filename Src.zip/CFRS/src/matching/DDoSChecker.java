package matching;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import logs.ObjectHolder;
import utilities.DialogUtility;
import GATE.SLA;
import GATE.SLOValue;

import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import com.mongodb.util.JSON;

/**
 * Check if a DDoS attack is present and store it into attacks MongoDB collection
 * 
 *
 */

public class DDoSChecker implements AttackChecker{
	private SLA sla;
	private int max;
	private long time;
    
	/**
	 * 
	 * @param sla : the SLA analyzed
	 */
	public DDoSChecker(SLA sla){
		this.sla = sla;
		time=-1;
	}

	/**
	 * waits for the end of all the SLO that compose DDoS attack (HUP,ART,NSC) and notify an eventual attack to user. Store it 
	 * into attacks MongoDB collection
	 */
	public void run() {
		ArrayList<Integer> periodsArray = new ArrayList<Integer>();
		Iterator<SLOValue> uptimeIt = sla.getSLO("uptime").getValues().iterator();
		Iterator<SLOValue> avgResIt = sla.getSLO("averageResponseTime").getValues().iterator();
		Iterator<SLOValue> numOfConnIt = sla.getSLO("numberOfConnections").getValues().iterator();

		while(uptimeIt.hasNext())
			periodsArray.add((int)(Double.parseDouble(uptimeIt.next().getslovaluedef().getPeriod())));
		while(avgResIt.hasNext())
			periodsArray.add((int)(Double.parseDouble(avgResIt.next().getslovaluedef().getPeriod())));
		while(numOfConnIt.hasNext())
			periodsArray.add((int)(Double.parseDouble(numOfConnIt.next().getslovaluedef().getPeriod())));

		//get the max period to wait
		max = -1;
		for(int i:periodsArray){
			max = Math.max(max, i);
		}

		try {
			while(true){
				//Thread.sleep(5000); //debug
				Thread.sleep(max*60*1000); //original
				boolean attack=checkAttack();
				if(attack){
					String message="Warning: possible DDoS attack on your system!";
					(new Thread(new DialogUtility(message))).start();
					BasicDBObject att=new BasicDBObject("Attack", "DDoS")
					.append("Time",time); 
                     ObjectHolder.dbattacks.insertObject(att);
				}


			}

		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

	/**
	 * controls information from violation db and checks if there is the DDoS attack 
	 * @return true: if all the violations (HUP, ART, NSC) are checked
	 *         false: otherwise
	 */
	 
	public boolean checkAttack(){
		//long time = Calendar.getInstance().getTimeInMillis(); //get time (correct implementation with realtime log)-commented for testing

		if(time<0){
			time=(Long) ObjectHolder.db.getMin("Time").get("Time");
		}

		time = time + max*60*1000;
		long uptimeViolation=ObjectHolder.dbviolations.count((BasicDBObject)JSON.parse("{ $and : [{SLO : \"hourlyUptimePercentage\"},{Time : {$gte : "+(time-60*60*1000)+"}}, {Time:{$lte :"+time+"}}]}"));
		long averageResponseTimeViolations=ObjectHolder.dbviolations.count((BasicDBObject)JSON.parse("{ $and : [{SLO : \"averageResponseTime\"},{Time : {$gte : "+(time-60*60*1000)+"}}, {Time:{$lte :"+time+"}}]}"));
		long numConnViolations=ObjectHolder.dbviolations.count((BasicDBObject)JSON.parse("{ $and : [{SLO : \"numberOfConnections\"},{Time : {$gte : "+(time-60*60*1000)+"}}, {Time:{$lte :"+time+"}}]}"));
		if((uptimeViolation>0) && (averageResponseTimeViolations>0) && (numConnViolations>0)){
			DBObject maxuptime=ObjectHolder.dbviolations.getMin("Difference","{ $and : [{SLO : \"hourlyUptimePercentage\"},{Time : {$gte : "+(time-60*60*1000)+"}}, {Time:{$lte :"+time+"}}]}");
			Double maxuptimevalue=Double.parseDouble(maxuptime.get("Difference").toString());
			DBObject maxavgrestime=ObjectHolder.dbviolations.getMax("Difference","{ $and : [{SLO : \"averageResponseTime\"},{Time : {$gte : "+(time-60*60*1000)+"}}, {Time:{$lte :"+time+"}}]}");
			Double maxavgrestimevalue=Double.parseDouble(maxavgrestime.get("Difference").toString());
			DBObject maxnumconn=ObjectHolder.dbviolations.getMax("Difference","{ $and : [{SLO : \"numberOfConnections\"},{Time : {$gte : "+(time-60*60*1000)+"}}, {Time:{$lte :"+time+"}}]}");
			Double maxnumconnvalue=Double.parseDouble(maxnumconn.get("Difference").toString());
			Map<String,Double> toTrain=new HashMap<String,Double>();
			toTrain.put("hourly_uptime", maxuptimevalue);
			toTrain.put("average_response_time",maxavgrestimevalue);
			toTrain.put("number_of_connections",maxnumconnvalue);
			toTrain.put("Attack",1.0);
			ObjectHolder.train.insertAttack(toTrain);
			return true;
		}
		else{
			return false;
		}
	}
}
