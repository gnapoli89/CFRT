package matching;

import java.util.concurrent.Callable;
import net.sourceforge.jeval.EvaluationException;
import net.sourceforge.jeval.Evaluator;

/**
 * @Class Calculator
 * Used to evaluate a String formula 
 */
public class Calculator implements Callable<Double> {
	//thease variables will be used by AVG JEVAL function
	private String period;
	private String numOfMinutes;
	private String form;
	private String unit;
	private String sloName;

	public Calculator(String period, String valuetime,String form,String unit, String sloName){
		this.period = period;
		this.numOfMinutes = valuetime;
		this.form=form;
		this.unit=unit;
		this.sloName = sloName;
	}


	/**
	 * 
	 * Evaluates SLO formula and return the calculated value
	 * @return value evaluated from log using formula given to the constructor
	 * @throws EvaluationException 
	 * @throws NumberFormatException 
	 * */
	public Double call() throws EvaluationException {
		Double value;
		String formula=form;
		//manipulate formula to put interval for calculate average
		if(formula.contains("avg('")){
			String[] splitted = formula.split("avg\\(\\'");
			formula = splitted[0]+"avg('"+"<"+period+"><"+numOfMinutes+">"+"<"+unit+">"+"<"+sloName+">"+splitted[1];
		}
		
		if(formula.contains("count('")){
			String[] splitted = formula.split("count\\(\\'");
			formula = splitted[0]+"count('"+"<"+period+"><"+numOfMinutes+">"+"<"+unit+">"+"<"+sloName+">"+splitted[1];
		}
			

		Evaluator e = new Evaluator();
		
		//If a new function is needed add it here.
		
		e.putFunction(new AvgFunction());
		e.putFunction(new CountFunction());
		
		value=Double.valueOf(e.evaluate(formula));
	//System.out.println("formula: "+formula+" result: "+value);
	
		return value;
	}
}