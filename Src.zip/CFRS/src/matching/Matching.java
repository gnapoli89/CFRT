package matching;

import java.awt.Frame;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import javax.swing.JOptionPane;

import utilities.DialogUtility;

import com.mongodb.BasicDBObject;

import logs.ObjectHolder;

import net.sourceforge.jeval.EvaluationException;
import net.sourceforge.jeval.Evaluator;

import GATE.Definition;
import GATE.SLA;
import GATE.SLO;
import GATE.SLOValue;

/**
 * Control the presence of each SLO in SLA and, for each of them, launch its Matcher
 *
 *
 */

public class Matching implements Runnable {
	Map <SLOValue,Double> values;
	ArrayList<SLOValue> sloval;
	Map <SLOValue,Double> toReturn;
	SLA s;

	/**
	 * 
	 * @param s : The SLA analyzed
	 */
	public Matching(SLA s){
		this.s=s;
	}

	/** This method parse all SLO from an SLA object and for each SLO call Calculator 
	 * to get the real value.*/
	public void run(){
		HashSet<SLO> h=s.getSLOList();
		ArrayList<SLO> slos=new ArrayList<SLO>(h);
		for(int i=0;i<slos.size();i++){
			SLO sl = slos.get(i);
			sloval = new ArrayList<SLOValue> (sl.getValues());
			//toReturn is a map that links together theoretical value and real value
			toReturn = new HashMap<SLOValue,Double>();
			SLOMatcher sloMatch;

			if(sl.getName().equalsIgnoreCase("uptime")){
				for(int j=0;j<sloval.size();j++){	
					sloMatch=new UptimeMatcher(sl, sloval.get(j));
					new Thread (sloMatch).start();
				}
			}

			if(sl.getName().equalsIgnoreCase("averageResponseTime")){
				for(int j=0;j<sloval.size();j++){
					sloMatch=new AvgResTimeMatcher(sl, sloval.get(j));
					new Thread (sloMatch).start();
				}

			}
			
			if(sl.getName().equalsIgnoreCase("numberOfConnections")){
				for(int j=0;j<sloval.size();j++){
					sloMatch=new SimUsersMatcher(sl, sloval.get(j));
					new Thread (sloMatch).start();
				}

			}

		}

	}

	

}