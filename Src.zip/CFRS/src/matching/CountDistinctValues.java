package matching;

import java.util.List;
import java.util.concurrent.Callable;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCursor;

import logs.AWSDictionary;
import logs.ObjectHolder;

/** Average function invoked when a count function needs distinct values
 * 
 * 
 *
 */
public class CountDistinctValues implements Callable<String> {

	
	private String formula;
	private double period;
	private long limInf;
	private long limSup;
	private String result;
	
	/**
	 * 
	 * @param formula formula in count function
	 * @param periodDouble SLO period expressed in double
	 */

	public CountDistinctValues(String formula, double periodDouble) {
		result="";
		this.formula=formula;
		period=periodDouble;
		limInf = ObjectHolder.timeInf[2];
		limSup = ObjectHolder.timeSup[2];
	}
	@Override
	public String call() throws Exception {
		int index=0;
		int index1=0;

		if(limInf < 0 || limSup < 0){
			//limInf = Calendar.getInstance().getTimeInMillis();
			ObjectHolder.timeInf[2] = limInf = Long.parseLong(ObjectHolder.db.getMin("Time").get("Time").toString());
			ObjectHolder.timeSup[2] = limSup = ObjectHolder.timeInf[2]+(int)period*60000;
		}else{
			ObjectHolder.timeInf[2] = limInf = limSup;
			ObjectHolder.timeSup[2] = limSup = limInf+(int)period*60000;
		}


		
		String atom;
		String newFormula = formula;
		while(index>=0){
			index=newFormula.indexOf("[",index+1);
			index1=newFormula.indexOf("]",index+1);
			if(index<0)
				break;
			atom = newFormula.substring(index+1,index1);
			atom = atom.trim();
			
			//set parameters of interval of time into Dictionary
			while(AWSDictionary.in_use){
				Thread.sleep(1000);
			}
			ObjectHolder.dictionary.setlimInf(limInf);
			ObjectHolder.dictionary.setlimSup(limSup);
			
			List ips = ObjectHolder.db.distinct((BasicDBObject) ObjectHolder.dictionary.translate(atom),"RemoteIP");
			result=Integer.toString(ips.size());
			//System.out.println(result);
		}
		return result;
	}

}
