package matching;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import net.sourceforge.jeval.EvaluationException;
import net.sourceforge.jeval.Evaluator;
import utilities.DialogUtility;

import com.mongodb.BasicDBObject;

import logs.ObjectHolder;

import GATE.Definition;
import GATE.SLO;
import GATE.SLOValue;

/** Calculates, inserts into MongoDB data collection and matches Average Response Time (ART) values
 * 
 * 
 *
 */

public class AvgResTimeMatcher implements SLOMatcher{

	SLOValue sloValue;
	SLO slo;

	/**
	 ** @param slo: SLO object Average Response Time 
	 * @param v: A ART SloValue
	 */
	public AvgResTimeMatcher(SLO slo, SLOValue v){
		sloValue = v;
		this.slo = slo;
	}

	/**
	 * calculates ART value every period and stores it into MongoDB data collection 
	 * 
	 */
	public void run() {
		Definition d = sloValue.getslovaluedef();
		String form = d.getForm();
		String period = d.getPeriod();
		String valuetime = d.getValuetime();
		String unit=d.getUnit();
		Boolean flag = true;

		Calculator calculator = new Calculator(period, valuetime,form, unit, slo.getName());

		ExecutorService e = Executors.newFixedThreadPool(1);

		//get result from task and saves it into DB
		while(flag){
			Future<Double> futureResult = e.submit(calculator);
			try {
				Double result = futureResult.get();
				BasicDBObject toInsert = new BasicDBObject("Type", "average_response_time")
				.append("Value", result)
				.append("Time", ObjectHolder.timeSup[1]);

				ObjectHolder.dbdata.insertObject(toInsert);
				
				this.matchSLAValue(sloValue, result, slo.getName());


			} catch (InterruptedException | ExecutionException e1) {
				if (e1.getCause() instanceof EvaluationException){
					System.out.println("Formula not supported. Impossible evaluation.");
					//show violation alert
					String message="Violation on "+slo.getName()+" formula not supported.";
					(new Thread(new DialogUtility(message))).start();
					//insert violation in DB
					BasicDBObject vio=new BasicDBObject("SLO", slo.getName())
											.append("Difference", "Formula not valid")
											.append("Unit", sloValue.getUnit())
											.append("Time",ObjectHolder.timeSup[0]); 
					ObjectHolder.dbviolations.insertObject(vio); 
					
					flag = false; //it stops calculate this SLO value
				}
				e1.printStackTrace();
			}

		}

	}

	
	/** 
	 * Matches every ART calculated value with SLO one: if a violation is found notifies it to the user and stores it into
	 * MongoDB violation database
	 */
	public void matchSLAValue(SLOValue sloValue, Object realvalue,String sloName) {
		String value = sloValue.getValue();
		String operator = sloValue.getOperator();
		String formula = value+operator+realvalue;
		Evaluator e = new Evaluator();
		
		try {
			Double result=Double.valueOf(e.evaluate(formula));
			result=Math.round(result*100.00)/100.00;
			Double difference=(Double)realvalue-Double.valueOf(value);
			difference=Math.round(difference*100.00)/100.00;
			if(result==1.0){
				String message="Violation on "+sloName+"with difference of " +difference+sloValue.getUnit();
				(new Thread(new DialogUtility(message))).start();
				BasicDBObject vio=new BasicDBObject("SLO", sloName)
				.append("Difference", difference)
				.append("Unit", sloValue.getUnit())
				.append("Time",ObjectHolder.timeSup[1]); 
				ObjectHolder.dbviolations.insertObject(vio); 
			} 	


		} catch (EvaluationException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}


	}
}