package matching;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import utilities.TimerTaskUtility;

import net.sourceforge.jeval.Evaluator;
import net.sourceforge.jeval.function.Function;
import net.sourceforge.jeval.function.FunctionConstants;
import net.sourceforge.jeval.function.FunctionException;
import net.sourceforge.jeval.function.FunctionResult;

/** JEval function for count. Launched when in SLO formula "count(" is found
 * 
 * 
 *
 */

public class CountFunction implements Function {
	
	String result="";

	/** Calculates the number of elements of the formula 
     *  @param evaluator a JEval evaluator
     *  @param args formula into count with parameters
     *  @return a FunctionResult JEval object with calculation result
     */
	public FunctionResult execute(Evaluator eval, String args)
			throws FunctionException {
		String unit="null";
		String period="null";
		String valueTime="null";
		String sloName="null";
		String regex = "[']<(\\d+.\\d+)><(\\d+)><(.+)><(\\w+)>(.)*";
		Pattern pattern = Pattern.compile(regex);
		
		Matcher m = pattern.matcher(args);
		if (m.matches()) {	
			period = m.group(1);
			valueTime = m.group(2);
			unit=m.group(3);
			sloName = m.group(4);
			//clear the formula removing all parameters
			args = args.replaceAll("<(\\d+.\\d+)><(\\d+)><(.+)><(\\w+)>", "");
			//System.out.println("Sono in AVG; ho preso valuetime e period: "+args);
		}else{
			System.out.println(args+" not matches");
			//toDo implement Exception 
		}

		double periodDouble= Double.parseDouble(period);
		int numOfMinutesInt = Integer.parseInt(valueTime);
		ExecutorService e1=Executors.newFixedThreadPool(1);
		ExecutorService e2=Executors.newFixedThreadPool(1);
		TimerTaskUtility timer=new TimerTaskUtility((int)periodDouble*60000);
		Callable<String> mytask=null;
		//if(sloName.equalsIgnoreCase("numberOfConnections")){
		mytask=new CountDistinctValues(args,periodDouble);
		//}
		Future<Long> timeRes = e2.submit(timer);
		//starts calculation
		Future<String> fresult = e1.submit(mytask);
		try {
			result=fresult.get();
			timeRes.get();
		}catch (ExecutionException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return new FunctionResult(result,FunctionConstants.FUNCTION_RESULT_TYPE_NUMERIC);
	}

	@Override
	public String getName() {
		return "count";
	}

}
