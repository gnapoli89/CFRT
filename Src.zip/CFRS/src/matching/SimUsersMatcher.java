package matching;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import net.sourceforge.jeval.EvaluationException;
import net.sourceforge.jeval.Evaluator;
import utilities.DialogUtility;

import logs.ObjectHolder;

import com.mongodb.BasicDBObject;

import GATE.Definition;
import GATE.SLO;
import GATE.SLOValue;

/** Calculates, inserts into MongoDB data collection and matches Number of Simultaneous Connections (NSC) SLO values
 *  
 * 
 *
 */
public class SimUsersMatcher implements SLOMatcher {

	SLOValue sloValue;
	SLO slo;
	
	/**
	 ** @param slo SLO object Number of Simultaneous Connections
	 * @param v A NSC SloValue
	 */
	
	public SimUsersMatcher(SLO sl, SLOValue sloValue) {
		this.sloValue = sloValue;
		this.slo = sl;
	}

	/**
	 * calculates NSC value every period and stores it into MongoDB data collection 
	 * 
	 */
	public void run() {
		Definition d = sloValue.getslovaluedef();
		String form = d.getForm();
		String period = d.getPeriod();
		String valuetime = d.getValuetime();
		String unit=d.getUnit();
		Boolean flag = true;

		Calculator calculator = new Calculator(period, valuetime,form, unit, slo.getName());

		ExecutorService e = Executors.newFixedThreadPool(1);
        int i=0;
		//get result from task and saves it into DB
		while(flag){
			Future<Double> futureResult = e.submit(calculator);
			try {
				Double result = futureResult.get();
				BasicDBObject toInsert = new BasicDBObject("Type", "number_simultaneous_connections")
				.append("Value", result)
				.append("Time", ObjectHolder.timeSup[2]);

				ObjectHolder.dbdata.insertObject(toInsert);
				//System.out.println("SimUsers Value number "+i+": "+result);
				this.matchSLAValue(sloValue, result, slo.getName());
                i++;

			} catch (InterruptedException | ExecutionException e1) {
				if (e1.getCause() instanceof EvaluationException){
					System.out.println("Formula not supported. Impossible evaluation.");
					//show violation alert
					String message="Violation on "+slo.getName()+" formula not supported.";
					(new Thread(new DialogUtility(message))).start();
					//insert violation in DB
					BasicDBObject vio=new BasicDBObject("SLO", slo.getName())
											.append("Difference", "Formula not valid")
											.append("Unit", sloValue.getUnit())
											.append("Time",ObjectHolder.timeSup[0]); 
					ObjectHolder.dbviolations.insertObject(vio); 
					
					flag = false; //it stops calculate this SLO value
				}
				e1.printStackTrace();
			}

		}

	}

	/** 
	 * Matches every NSC calculated value with SLO one: if a violation is found notifies it to the user and stores it into
	 * MongoDB violation database
	 */
	public void matchSLAValue(SLOValue sloValue, Object realvalue,String sloName) {
		String value = sloValue.getValue();
		String operator = sloValue.getOperator();
		String formula = value+operator+realvalue;
		Evaluator e = new Evaluator();
		try {
			Double result=Double.valueOf(e.evaluate(formula));
			result=Math.round(result*100.00)/100.00;
			Double difference=(Double)realvalue-Double.valueOf(value);
			if(result==1.0){
				int differenceint=difference.intValue();
				String message="Violation on "+sloName+"with difference of " +differenceint+ " connections";
				(new Thread(new DialogUtility(message))).start();
				BasicDBObject vio=new BasicDBObject("SLO", sloName)
				.append("Difference", difference)
				.append("Unit", sloValue.getUnit())
				.append("Time",ObjectHolder.timeSup[2]); 
				ObjectHolder.dbviolations.insertObject(vio); 
			} 	


		} catch (EvaluationException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}


	}
		
		
	}


