package utilities;

import java.util.Calendar;
import java.util.concurrent.Callable;

/** 
 *This task is used to wait a number of mills and 
 *return the actual mills when it finishes to sleep 
 */
public class TimerTaskUtility implements Callable<Long>{

	long time;
	
	public TimerTaskUtility(long mills){
		//time = mills;
		time = 500;
	}

	/**
	 * Sleeps for a number of mills equal to time
	 * @return number of mills in UNIX time when the method returns
	 */
	@Override
	public Long call() throws Exception {
		try {
			Thread.sleep(time);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return Calendar.getInstance().getTimeInMillis();
	}
	

}
