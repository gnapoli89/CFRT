package utilities;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;

/** Utility class used to populate the training set attacks
 * 
 * 
 *
 */
public class TrainSetUtility {
	
	private int trainSetSize; //put in a file in the future
	private String[] sloOrder={"hourly_uptime","average_response_time","number_of_connections"};
	
	/**
	 * Add a new attack in the training set train_set.txt
	 * @param entryMap: Map with key SLO name and value its last value in Double (one entry for every SLO)
	 */
	
	public void insertAttack(Map<String,Double> entryMap){
		//store the entry in the train set db
		String stringToFile="";
		for(int i=0;i<sloOrder.length;i++){
			Double value=entryMap.get(sloOrder[i]);
			if(value == null){
				stringToFile+="0,";
			}
			else{
				stringToFile+=(value+",");
			}
		}
		stringToFile+=entryMap.get("Attack");
		
		try(PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter("train_set.txt", true)))) {
		    out.println(stringToFile);
		    this.trainSetSize++;
		}catch (IOException e) {
		    //exception handling left as an exercise for the reader
		}
	}



	public int getTrainSetSize() {
		return trainSetSize;
	}



	
	
}
