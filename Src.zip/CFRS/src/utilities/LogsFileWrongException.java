package utilities;

/**
 * Exception launched when a wrong log file is setted
 * 
 *
 */
public class LogsFileWrongException extends Exception {

	public LogsFileWrongException(){
		
	}
}
