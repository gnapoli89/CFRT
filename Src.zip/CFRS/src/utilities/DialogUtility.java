package utilities;

import java.awt.Frame;

import javax.swing.JOptionPane;
/** 
 * Class utility for dialog windows
 * 
 *
 */
public class DialogUtility implements Runnable {
	
	String message;
	/**
	 * 
	 * @param message: message to visualize in window
	 */
	public DialogUtility(String message){
		this.message=message;
	}

	/**
	 * Shows the warning popup window 
	 */
	@Override
	public void run() {
		Frame frame=new Frame();
		JOptionPane.showMessageDialog(frame,
			    message,
			    "Warning",
			    JOptionPane.WARNING_MESSAGE);

	}

}
