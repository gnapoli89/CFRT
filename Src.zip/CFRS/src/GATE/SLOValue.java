package GATE;
/** Java Bean for table SLOValue
 * 
 * 
 *
 */
public class SLOValue {

	
	private String valuetime;
	private String value;
	private String operator;
	private String unit;
	private String service;
	private Definition slovaldefinition;

public SLOValue(String time, String value, String operator, String unit,String service,Definition slometric) {
		this.valuetime = time;
		this.value = value;
		this.operator = operator;
		this.unit=unit;
		this.service=service;
		slovaldefinition=slometric;}

public String getValuetime() {
	return valuetime;
}

public String getValue() {
	return value;
}

public String getOperator() {
	return operator;
}
public String getUnit(){
	return unit;
}
public String getService(){
	return service;
}

public Definition getslovaluedef(){
	return slovaldefinition;
}

}