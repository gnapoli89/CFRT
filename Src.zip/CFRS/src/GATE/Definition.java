package GATE;

/** Java Bean for table Definition
 * 
 * 
 *
 */
public class Definition  {

	private String name;
	private String form;
	private String period;
	private String unit;
	private String valuetime;
	private String service;
	
	public Definition(String name,String form, String period, String unit,String valuetime,String service){
		this.name=name;
		this.form=form;
		this.unit=unit;
		this.period=period;
		this.valuetime=valuetime;
		this.service=service;
	}

	public Definition() {
		// TODO Auto-generated constructor stub
	}

	public String getName() {
		return name;
	}

	public String getForm() {
		return form;
	}

	public String getPeriod() {
		return period;
	}

	public String getUnit() {
		return unit;
	}

	public String getValuetime() {
		return valuetime;
	}
	public String getService(){
		return service;
	}
	
	public void setForm(String form) {
		this.form=form;
		
	}

	public void setValueTime(String valuetime) {
		this.valuetime=valuetime;
		
	}
	
	

}
