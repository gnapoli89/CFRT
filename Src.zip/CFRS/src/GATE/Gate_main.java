package GATE;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StreamCorruptedException;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.SQLException;

import storage.SlaDB;
import utilities.DialogUtility;
import gate.*;
import gate.creole.*;
import gate.persist.PersistenceException;
import gate.util.*;
import gate.util.persistence.PersistenceManager;
/** 
 * Inizialize and starts GATE using its parameters, creates SLA database and stores SLA information into it 
 * 
 *
 */

public class Gate_main {
	

	public static void gate_run() throws ClassNotFoundException, SQLException, MalformedURLException, GateException {
		// initialise GATE
		
		File fileDir = new File("conf_file.txt");
		BufferedReader textreader=null;
		try {
			textreader = new BufferedReader(
					   new InputStreamReader(
			                      new FileInputStream(fileDir), "UTF-8"));
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		String line="";
		String gate_home="";
		String gate_app="";
		String sla_file="";
		try {
			while((line=textreader.readLine())!= null){
				int indexhome=line.indexOf("GATE_home=");
				if(indexhome>=0){
					String[] gate_home_line=line.split("GATE_home=");
					gate_home=gate_home_line[1];
				}
				int indexapp=line.indexOf("GATE_app=");
				if(indexapp>=0){
					String[] gate_app_line=line.split("GATE_app=");
					gate_app=gate_app_line[1];
				}
				int indexsla=line.indexOf("SLA_file=");
				if(indexsla>=0){
				    String[] sla_file_line=line.split("SLA_file=");
					sla_file=sla_file_line[1];
				}
			}
			textreader.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		  catch (ArrayIndexOutOfBoundsException e){
			  String message="One or more configuration parameters are empty: please restart FRS and insert correct ones";
				(new Thread(new DialogUtility(message))).start();
		  }
		
 		
		
		Gate.setGateHome(new File(gate_home));
		org.apache.log4j.BasicConfigurator.configure();
		org.apache.log4j.Logger.getRootLogger().setLevel(org.apache.log4j.Level.OFF);
		
		try {
			Gate.init();
		} catch (GateRuntimeException e) {
			// exception launched when GATE_home is setted to a wrong parameter
			String message="GATE home wrong!! Please restart FRS and insert the correct directory";
			(new Thread(new DialogUtility(message))).start();
			e.printStackTrace();
		}

		// load ANNIE plugin - you must do this before you can create tokeniser
		// or JAPE transducer resources.
		try {
			Gate.getCreoleRegister().registerDirectories(
			   new File(Gate.getPluginsHome(), "ANNIE").toURI().toURL());
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (GateException e) {
			e.printStackTrace();
		}
		CorpusController app = null;
		try {
			app = (CorpusController) PersistenceManager.loadObjectFromFile(new File(gate_app));
		} catch (PersistenceException e) {
			e.printStackTrace();
		} catch (ResourceInstantiationException | StreamCorruptedException e ) {
			// exception launched when GATE_app is setted to a wrong parameter
			String message="GATE application file wrong!! Please restart FRS and insert the correct file";
			(new Thread(new DialogUtility(message))).start();
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}  
		// create document and corpus
		Corpus corpus;
		Document doc = null;
		try {
			corpus = Factory.newCorpus("SLA");
			doc = Factory.newDocument(new URL(sla_file));
			corpus.add(doc);
			app.setCorpus(corpus);

		} catch (ResourceInstantiationException e) {
			//exception launched when SLA_file is setted to a wrong parameter
			String message="The SLA file setted is not a SLA document: please restart FRS and insert a correct file";
			(new Thread(new DialogUtility(message))).start();
			e.printStackTrace();
		}
		
		// run it
		app.execute();

		// extract results
		String provider=(String)doc.getFeatures().get("provider");
		String service=(String)doc.getFeatures().get("cloud_service");
		AnnotationSet SLO=doc.getAnnotations().get("SLO");
		AnnotationSet definition=doc.getAnnotations().get("Definition");
	    SlaDB db=new SlaDB();
		db.add(provider,service);
		DefinitionSet metraggr=new DefinitionSet(definition,provider,service);
		SLA serlevaggr=new SLA(provider,service, SLO,metraggr);
		System.out.println("GATE terminated");

	}

}
