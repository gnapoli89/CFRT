package GATE;

import java.util.HashSet;
import java.util.Iterator;

import storage.SloValueDB;


/** Java Bean for table SLO
 * 
 * 
 *
 */
public class SLO {
  private String name;	
  private HashSet<SLOValue> values;
  

  public SLO(String name,HashSet<SLOValue> values) {
	this.name=name;
	this.values = values;
	
}

/**
 * iterate the values list and add them to DB
 * @param provider: SLA provider
 * @param service: SLA service
 * @throws ClassNotFoundException
 */
public void add_values_to_db(String provider, String service) throws ClassNotFoundException { 
	Iterator it=values.iterator();
	while(it.hasNext()){
		SloValueDB sld=new SloValueDB();
		SLOValue v=(SLOValue)it.next();
		sld.add(v,name,provider,service);
	}
	
	
}


public void setValues(HashSet<SLOValue> values) {
		this.values = values;
	}  
  
public String getName(){
	return name;
}
  
public HashSet<SLOValue> getValues() {
	return values;
}


 
  
}