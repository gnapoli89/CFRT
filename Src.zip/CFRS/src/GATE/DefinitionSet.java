package GATE;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;

import storage.DefinitionDB;
import gate.*;
/**
 * Class that manages "Definition" annotations 
 * 
 *
 */
public class DefinitionSet {
private HashSet<Definition> definitions=new HashSet<Definition>();
private String provider;
private String service;
	public DefinitionSet(AnnotationSet Definition,String provider,String service) throws ClassNotFoundException {
		this.provider=provider;
		this.service=service;
		setDefinitions(Definition);
		
	}
	
	public DefinitionSet(HashSet<Definition> definitions, String provider, String service){
		this.definitions=definitions;
		this.provider=provider;
		this.service=service;
	}
	
	
	public HashSet<Definition> getDefinitions(){
		return definitions;
	}

	
	
	/** build the Definition HashSet
	 * 
	 * @param Definitions: AnnotationSet of "Definition" annotations
	 * @throws ClassNotFoundException
	 */
	private void setDefinitions(AnnotationSet Definitions) throws ClassNotFoundException {
	     List itDefinitions=new ArrayList(Definitions);
		 Collections.sort(itDefinitions,new gate.util.OffsetComparator());
		 for(int i=0;i<itDefinitions.size();i++){
			 Annotation a=(Annotation)itDefinitions.get(i);
			 String name=(String)a.getFeatures().get("kind");
			 int def=name.indexOf("_definition");
			 String form=(String)a.getFeatures().get("form_"+name.substring(0, def));
			 String period=(String)a.getFeatures().get("period");
			 String unit=(String)a.getFeatures().get("unit");
			 String valuetime=(String)a.getFeatures().get("valuetime");
			 String dservice=(String)a.getFeatures().get("service");
			 Definition met=new Definition(name, form, period, unit,valuetime,dservice);
			 DefinitionDB dd=new DefinitionDB();
			 dd.add(met,provider,service);
			 this.definitions.add(met);
		 }
		 setDefinitionconnections();
	}
	
	
	/**
	 * control if in one formula is present another Definition: if it is true the Definition name is substituted with its formula 
	 * @throws ClassNotFoundException
	 */
	private void setDefinitionconnections() throws ClassNotFoundException {
		Iterator <Definition> itDefinition=definitions.iterator();
		DefinitionDB dd=new DefinitionDB();
		Definition m1=new Definition();
		while(itDefinition.hasNext()){
			Definition m=itDefinition.next();
			String mform=m.getForm();
			Iterator <Definition> itDefinition1=definitions.iterator();
			while (itDefinition1.hasNext()){
				m1=itDefinition1.next();
				String name=m1.getName();
				int start= name.indexOf("_definition");
				String pattern=name.substring(0,start);
				StringTokenizer patt=new StringTokenizer(pattern,"_");
				String newpattern="";
				while(patt.hasMoreTokens()){
					String word=patt.nextToken();
				    char uppcha=Character.toUpperCase(word.charAt(0));
				    word=String.valueOf(uppcha)+word.substring(1,word.length());
				    newpattern=newpattern+" "+word;
				}
				
				if(mform.contains(newpattern)){
				   mform=mform.replace("["+mform.substring(mform.indexOf(newpattern),mform.indexOf("]")+1), m1.getForm()); //controllare problema della s
				   m.setForm(mform);
				   m1.setValueTime(m.getValuetime());
				   dd.add(m, provider, service);
				   dd.add(m1,provider,service);
			       //il valuetime del figlio sar� lo stesso del padre
				}
				
			    
				
			}
			
		}
		
	}
	
	
	
	
}
