package GATE;
import java.awt.List;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

import storage.SloDB;
import storage.SloValueDB;
import gate.*;

/** Java Bean for table SLA
 * 
 * 
 *
 */
public class SLA {
    private String provider;
    private String service;
	private HashSet<SLO> slo=new HashSet<SLO>();
	private DefinitionSet SLAdefinitions;
	
public SLA(String provider, String service, AnnotationSet newslo,DefinitionSet definitions) throws ClassNotFoundException{
	this.provider=provider;
	this.service=service;
	SLAdefinitions=definitions;
	setSLO(newslo);
}

public SLA(String provider2, String service2, HashSet<SLO> slo2,
		DefinitionSet definitions) {
	this.provider=provider2;
	this.service=service2;
	this.slo=slo2;
	SLAdefinitions=definitions;
}

public DefinitionSet getSLAmetrics() {
	return SLAdefinitions;
}

public String getProvider() {
	return provider;
}

public String getService() {
	return service;
}

public HashSet<SLO> getSLOList() {
	return slo;
}

/**
 * Create the SLO hashset and for each one creates SLOValue list and corresponding definitions 
 * @param newslo: the AnnotationSet of "SLO" annotations
 * @throws ClassNotFoundException
 */
private void setSLO(AnnotationSet newslo) throws ClassNotFoundException{    
	ArrayList<Annotation> itannot=new ArrayList<Annotation>(newslo);
	for(int i=0;i<itannot.size();i++){
		Annotation a=(Annotation)itannot.get(i);
		String name=(String)a.getFeatures().get("kind");
		String value=(String)a.getFeatures().get(name+"_value");
		String time=(String)a.getFeatures().get("valuetime");
		String unit=(String)a.getFeatures().get("unit");
		String operator=(String)a.getFeatures().get("operator");
		String service=(String)a.getFeatures().get("service");
		if(slo.contains(getSLO(name))){ //if we have a kind known it must be an other value for it
			SLO old=getSLO(name);
			slo.remove(old);
			Iterator<Definition> list= SLAdefinitions.getDefinitions().iterator();
			Definition slometric=null;
			while(list.hasNext()){
				Definition m=list.next();
				if(m.getName().equals(name+"_definition")){
					if(m.getService().equals(service))
						slometric=m;
					break;
				}
			}
			SLOValue v=new SLOValue(time,value,operator,unit,service,slometric);
			HashSet<SLOValue> oldset=old.getValues();
			oldset.add(v);
			old.setValues(oldset);
			slo.add(old);
		}
		else{            //else we search the corresponding metric in metric list (if present)and create a new SLO object
		HashSet<SLOValue> h=new HashSet<SLOValue>();
		Iterator<Definition> list= SLAdefinitions.getDefinitions().iterator();
		Definition slometric=null;
		while(list.hasNext()){
			Definition m=list.next();
			if(m.getName().equals(name+"_definition")){
				if(m.getService().equals(service))
					slometric=m;
				break;
			}
		}
		SLOValue v=new SLOValue(time,value,operator,unit,service,slometric);
		h.add(v);
		SLO s=new SLO(name,h);
		SloDB sd= new SloDB();
		sd.add(s,provider,this.service);
		slo.add(s);
		s.add_values_to_db(provider,this.service);
	}}
	
}

/**
 * Control if a particular SLO is present in the SLA
 * @param field: SLO name
 * @return true: if SLO is present
 * @return false: otherwise
 */
public boolean hasSLO(String field){ 
	if(getSLO(field)==null){
	    	return false;}
    else{    
	return true;}
}
/**
 * Return the object SLO with name "field"
 * @param field: SLO name
 * @return SLO: object SLO with SLO name "field"
 * @return null: if SLO object is not present
 */
public SLO getSLO(String field){ //return the object SLO with name "field" 
	ArrayList<SLO> itstring=new ArrayList<SLO>(slo);
	SLO result=null;
	for(int i=0;i<itstring.size();i++){
	    SLO temp=(SLO)itstring.get(i);
	    String strann=(String)temp.getName();
	    if(strann.equals(field)){
	    	result=temp;}
	    }
	return result;
}


}