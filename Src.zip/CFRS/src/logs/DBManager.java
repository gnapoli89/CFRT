package logs;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.net.UnknownHostException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import utilities.DialogUtility;
import utilities.LogsFileWrongException;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.Mongo;
import com.mongodb.util.JSON;


public class DBManager{
	private Mongo mongoClient = null;
	private DB mydb = null;
	private DBCollection collection = null; 

	public DBManager(String uri, int port){
		try {
			//open client
			mongoClient = new Mongo(uri, port);
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public DBManager(){
		try {
			//open client
			mongoClient = new Mongo("localhost", 27017);
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public long count(DBObject query){
		//System.out.println(collection.count(cmd));
		//System.out.println(query +" ----> "+ collection.count(query));
		return collection.count(query);
	}

	public DBCursor find(DBObject query){
		return collection.find(query);
	}

	public List distinct(DBObject query, String distinct){
		return collection.distinct(distinct, query);
	}

	public void setDatabase(String dbName){
		mydb = mongoClient.getDB(dbName);
	}

	public Iterable<String> collections(){
		return mydb.getCollectionNames();
	}

	public void setCollection(String cName){
		if(!mydb.collectionExists(cName)){
			collection = mydb.createCollection(cName, null);
		}else{
			collection = mydb.getCollection(cName);
		}
	}

	public void insertObject(BasicDBObject obj){
		collection.insert(obj);
	}

	public void closeConnection(){
		//close client
		mongoClient.close();
	}

	public String toString(){
		String toReturn= "";
		//print a list of object 
		DBCursor cursor = collection.find();
		while(cursor.hasNext()){
			toReturn = toReturn+cursor.next();
		}
		return toReturn;
	}

	/**
	 * Return the maximum of specified key 
	 */
	public DBObject getMax(String key){
		DBObject toReturn=null;
		DBCursor cursor = collection.find().sort( new BasicDBObject( key , -1 ) ).limit(1);
		while (cursor.hasNext()) {
			//	System.out.println(cursor.next());
			toReturn = cursor.next();
		}
		return toReturn;
	}


	public DBObject getMax(String key,String filter){
		DBObject toReturn=null;
		DBCursor cursor = collection.find((BasicDBObject)JSON.parse(filter)).sort( new BasicDBObject( key , -1 ) ).limit(1);
		while (cursor.hasNext()) {
			//	System.out.println(cursor.next());
			toReturn = cursor.next();
		}
		return toReturn;
	}


	/**
	 * Return the minimum of specified key 
	 */
	public DBObject getMin(String key){
		DBObject toReturn=null;
		DBCursor cursor = collection.find().sort( new BasicDBObject( key , 1 ) ).limit(1);
		while (cursor.hasNext()) {
			//	System.out.println(cursor.next());
			toReturn = cursor.next();
		}
		return toReturn;
	}

	public DBObject getMin(String key,String filter){
		DBObject toReturn=null;
		DBCursor cursor = collection.find((BasicDBObject)JSON.parse(filter)).sort( new BasicDBObject( key , 1 ) ).limit(1);
		while (cursor.hasNext()) {
			//	System.out.println(cursor.next());
			toReturn = cursor.next();
		}
		return toReturn;
	}


	public void LoadDB( String filePath){
		BasicDBObject DBobj;
		this.setDatabase("test");
		this.setCollection("log");
		String event;
		String regex = "([a-z0-9]+)\\s(\\w+)\\s\\[(\\d+)/(\\d+)/(\\d+)\\:(\\d+)\\:(\\d+)\\:(\\d+)\\s(\\+\\d+)\\]\\s([\\d+.]+)\\s([\\w|-]+)\\s([A-Z0-9]+)\\s([A-Z.]+)\\s([-a-zA-Z0-9+&@#/%?=~_|!:,.;'()]+)\\s\"([A-Z]+)\\s([-a-zA-Z0-9+&@#/%?=~_|!:,.;'()]+)\\s([A-Z.0-9/]+)\"\\s(\\d+)\\s([\\w|-]+)\\s(\\d+)\\s(\\d+)\\s(\\d+)\\s(\\d+)\\s\"([-a-zA-Z0-9+&@#/%?=~_|!:,.;'() ]+)\"\\s\"([\\w|\\W]+)\"\\s(.)+$";
		Pattern pattern = Pattern.compile(regex);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd:HH:mm:ss");
		int row = 0;
		try {
			BufferedReader bf = new BufferedReader(new FileReader(filePath));
			LineNumberReader  lnr = new LineNumberReader(bf);
			lnr.skip(Long.MAX_VALUE);
			int num_rows=lnr.getLineNumber();//Add 1 because line index starts at 0
			lnr.close();
			bf = new BufferedReader(new FileReader(filePath));
			// Finally, the LineNumberReader object should be closed to prevent resource leak
			int number_errors=0;
			while((event = bf.readLine()) != null){
				row++;
				Matcher m = pattern.matcher(event);
				if (m.matches()) {	
					/*STORE INSIDE DB*/
					DBobj = new BasicDBObject("BucketOwner", m.group(1))
					.append("BucketName",  m.group(2))
					.append("Day",  m.group(3))
					.append("Month",  m.group(4))
					.append("Year",  m.group(5))
					.append("Hours",  m.group(6))
					.append("Minutes",  m.group(7))
					.append("Seconds",  m.group(8))
					.append("Time", sdf.parse(m.group(5)+"/"+m.group(4)+"/"+m.group(3)+":"+m.group(6)+":"+m.group(7)+":"+m.group(8)).getTime())
					.append("GMT",  m.group(9))
					.append("RemoteIP",  m.group(10))
					.append("Requester",  m.group(11))
					.append("RequestID",  m.group(12))
					.append("Operation",  m.group(13))
					.append("Key",  m.group(14))
					.append("Request",  m.group(15))
					.append("URI",  m.group(16))
					.append("HTTPVer",  m.group(17))
					.append("HTTPStatus",  m.group(18))
					.append("ErrorCode",  m.group(19))
					.append("ByteSent",  m.group(20))
					.append("ObjectSize",  m.group(21))
					.append("TotalTime",  m.group(22))
					.append("TurnAroundTime",  m.group(23))
					.append("Referrer",  m.group(24))
					.append("UserAgent",  m.group(25))
					.append("VersionID",  m.group(26));

					//System.out.println(DBobj.toString());
					this.insertObject(DBobj);

				} else {
					number_errors++;
					System.out.println("does not match at row: "+row); 
				}
			}
			if(number_errors==num_rows){
				try {
					throw new LogsFileWrongException() ;
				} catch (LogsFileWrongException e) {
					// Exception launched when logs file is not correct
					String message="Logs file wrong!! Please restart FRS and insert the correct file";
					(new Thread(new DialogUtility(message))).start();
					e.printStackTrace();
					try {
						Thread.sleep(10000);
					} catch (InterruptedException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					System.exit(0);
				}
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();	}
		finally{

		}
	}
}
