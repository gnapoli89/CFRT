package storage;
import java.util.ArrayList;



import java.util.HashSet;
import java.sql.Connection;
import java.sql.DriverManager;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import GATE.Definition;
import GATE.DefinitionSet;
import GATE.SLA;
import GATE.SLO;
/**
 * Class that manages SLA database and table SLA in it 
 * 
 *
 */
public class SlaDB {
	
	public SlaDB() throws SQLException{
		control_if_db_exists();
	}

	/** 
	 * Control if SLA database already exists
	 * @throws SQLException
	 */
    private void control_if_db_exists() throws SQLException {
    	Connection cn= DriverManager.getConnection("jdbc:mysql://localhost/sla?user=root&password=");
		Statement st=cn.createStatement();
		String sql="SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = 'sla'";
		ResultSet rs=st.executeQuery(sql);
		rs.last();
        int size = rs.getRow();
        if(size==0){
        	create_sla_db();
        }
		
	}

    /** 
     * Create SLA database 
     * @throws SQLException
     */
	private void create_sla_db() throws SQLException {
		Connection cn= DriverManager.getConnection("jdbc:mysql://localhost/sla?user=root&password=");
		Statement st=cn.createStatement();
		String sql="CREATE DATABASE sla"; //create sla
		st.executeUpdate(sql);
		//create table definition
		sql="CREATE TABLE IF NOT EXISTS `definition` (`id_SLA` int(11) NOT NULL,`name` varchar(50) NOT NULL,"
             +"`form` varchar(500) NOT NULL,`period` varchar(100) NOT NULL,`valuetime` varchar(40) NOT NULL,"
             +"`unit` varchar(5) NOT NULL,`service` varchar(50) NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=latin1;";
		st.executeUpdate(sql);
		//create table sla
		sql="CREATE TABLE IF NOT EXISTS `sla` (`ID` int(11) NOT NULL,"
				+ "`provider` varchar(30) NOT NULL,`service` varchar(60) NOT NULL)"
				+ " ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;";
		st.executeUpdate(sql);
		//create table slo
		sql="CREATE TABLE IF NOT EXISTS `slo` (`name` varchar(40) NOT NULL,"
				+ "`id_sla` int(11) NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=latin1;";
		st.executeUpdate(sql);
        //create table slo_value
		sql="CREATE TABLE IF NOT EXISTS `slo_value` (`id_SLA` int(11) NOT NULL,"
				+ "`name` varchar(40) NOT NULL,`value` float NOT NULL,"
				+ "`valuetime` varchar(20) NOT NULL,`operator` varchar(2) NOT NULL,"
				+ "`unit` varchar(5) NOT NULL,`value_service` varchar(60) NOT NULL,"
				+ "`def_name` varchar(50) NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=latin1;";
		st.executeUpdate(sql);
		//indexes for "definition"
		sql="ALTER TABLE `definition` ADD PRIMARY KEY (`id_SLA`,`name`), ADD KEY `name` (`name`),"
				+ " ADD KEY `name_2` (`name`);";
		st.executeUpdate(sql);
		//Indexes for table `sla`
		sql="ALTER TABLE `sla` ADD PRIMARY KEY (`ID`);";
		st.executeUpdate(sql);
	    //Indexes for table `slo`
		sql= "ALTER TABLE `slo`ADD PRIMARY KEY (`name`,`id_sla`),"
				+ "ADD KEY `id_sla` (`id_sla`), ADD KEY `id_sla_2` (`id_sla`), "
				+ "ADD KEY `name` (`name`), ADD KEY `id_sla_3` (`id_sla`);";
		st.executeUpdate(sql);
		//Indexes for table `slo_value`
		sql="ALTER TABLE `slo_value` ADD PRIMARY KEY (`id_SLA`,`name`,`value`),"
				+ " ADD KEY `slo_value_ibfk_2` (`name`), ADD KEY `def_name` (`def_name`);";
		st.executeUpdate(sql);
		//AUTO_INCREMENT for table `sla`
		sql="ALTER TABLE `sla` MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=1;";
		st.executeUpdate(sql);
	    //Limiti per la tabella `definition`
		sql="ALTER TABLE `definition` ADD CONSTRAINT `definition_ibfk_1` FOREIGN KEY (`id_SLA`) REFERENCES `sla` (`ID`)"
				+ " ON DELETE CASCADE ON UPDATE CASCADE;";
		st.executeUpdate(sql);
		//Limiti per la tabella `slo`
		sql="ALTER TABLE `slo` ADD CONSTRAINT `slo_ibfk_1` FOREIGN KEY (`id_sla`) "
				+ "REFERENCES `sla` (`ID`) ON DELETE CASCADE;";
		st.executeUpdate(sql);
		//Limiti per la tabella `slo_value`
		sql="ALTER TABLE `slo_value` ADD CONSTRAINT `slo_value_ibfk_1` FOREIGN KEY (`id_SLA`) "
				+ "REFERENCES `slo` (`id_sla`) ON DELETE CASCADE ON UPDATE CASCADE, "
				+ "ADD CONSTRAINT `slo_value_ibfk_2` FOREIGN KEY (`name`) REFERENCES `slo` (`name`) "
				+ "ON DELETE CASCADE ON UPDATE CASCADE,	ADD CONSTRAINT `slo_value_ibfk_3` FOREIGN KEY (`def_name`) "
				+ "REFERENCES `definition` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;";
		st.executeUpdate(sql);
	}


	/**
	 * Add a new SLA to SLA table
	 * @param provider: SLA provider
	 * @param service: SLA service
	 * @return the number of rows affected (1 if there are no errors)
	 * @throws ClassNotFoundException
	 */
	public int add(String provider, String service) throws ClassNotFoundException{
       Class.forName("com.mysql.jdbc.Driver");
  	   
  	   try {
		
  		Connection cn= DriverManager.getConnection("jdbc:mysql://localhost/sla?user=root&password=");
		Statement st=cn.createStatement();
		if(take_id_from_key(provider,service)==-1){
  	    String sql="INSERT INTO sla (provider,service) VALUES ('"+provider+"','"+service+"')";
  	    return st.executeUpdate(sql);}
		else{  //aggiornamento dello SLA:elimino la vecchia tupla e reinserisco
			String sql="DELETE FROM sla WHERE provider='"+provider+"' AND service='"+service+"'";
			st.executeUpdate(sql);
			return add(provider,service);
		}
  	   } catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();return 0;
	}
    }
    
	/**
	 * Return the SLA id from provider and service (table primary key)
	 * @param provider: SLA provider
	 * @param service : SLA service
	 * @return SLA id
	 * @throws ClassNotFoundException
	 */
    public int take_id_from_key(String provider, String service) throws ClassNotFoundException{
    	Class.forName("com.mysql.jdbc.Driver");
   	   
   	   try {
 		Connection cn= DriverManager.getConnection("jdbc:mysql://localhost/sla?user=root&password=");
 		Statement st=cn.createStatement();
 		String sql="SELECT ID FROM sla WHERE provider='"+provider+"' AND service='"+service+"'";
 		ResultSet rs=st.executeQuery(sql);
 		if(rs.next()){
 			return rs.getInt("ID");
 		}
 		else{
 			return -1;
 		}
   	   } catch (SQLException e) {
   		// TODO Auto-generated catch block
   		e.printStackTrace();return 0;
   	}
    }


    /**
     * Extract all SLAs from SLA table 
     * @return an Arraylist of all SLAs present in DB
     * @throws ClassNotFoundException
     */
	public ArrayList<SLA> getAllSLA() throws ClassNotFoundException {
		Class.forName("com.mysql.jdbc.Driver"); 
	   	   try {
	 		Connection cn= DriverManager.getConnection("jdbc:mysql://localhost/sla?user=root&password=");
	 		Statement st=cn.createStatement();
	 		String sql="SELECT * FROM sla";
	 		ResultSet rs=st.executeQuery(sql);
	 		ArrayList<SLA> list=new ArrayList<SLA>();
	 		while (rs.next()){
	 			String provider=rs.getString("provider");
	 			String service=rs.getString("service");
	 			int id=rs.getInt("ID");
	 			SloDB slod=new SloDB(); 
	 			HashSet<SLO> slo=slod.getSLObyId(id);
	 			DefinitionDB dd=new DefinitionDB();
	 			HashSet<Definition> def=dd.getDefbyId(id);
	 			DefinitionSet definitions=new DefinitionSet(def,provider,service);
	 			SLA s=new SLA(provider,service,slo,definitions);
	 			list.add(s);
	 		}
	   
		return list;
	}
	   	catch (SQLException e) {
	   		// TODO Auto-generated catch block
	   		e.printStackTrace();return null;}
}
}
