package storage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashSet;

import GATE.Definition;
import GATE.SLOValue;

/**
 * Class that manages table slo_value in SLA database
 * 
 *
 */
public class SloValueDB {

	public SloValueDB(){}
	
	/**
	 * Add a new SLOValue to SLA DB
	 * @param s: SLOValue to add
	 * @param name: SLO name
	 * @param provider: SLA provider
	 * @param service: SLA service
	 * @return The number of rows affected (1 if there are no errors)
	 * @throws ClassNotFoundException
	 */
	public int add(SLOValue s, String name, String provider, String service)throws ClassNotFoundException{
	       Class.forName("com.mysql.jdbc.Driver");
	  	   
	  	   try {
			Connection cn= DriverManager.getConnection("jdbc:mysql://localhost/sla?user=root&password=");
			Statement st=cn.createStatement();
			SlaDB sd=new SlaDB();
			int id=sd.take_id_from_key(provider, service);
	  	    String sql="INSERT INTO slo_value (id_SLA,name,value,valuetime,operator,unit,value_service,def_name) VALUES ('"+id+"','"+name+"','"+s.getValue()+"','"+s.getValuetime()+"','"+s.getOperator()+"','"+s.getUnit()+"','"+s.getService()+"','"+s.getslovaluedef().getName()+"')";
	  	    return st.executeUpdate(sql);
	  	   } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();return 0;
		}
	    }

	/**
	 * 
	 * Get all SLOValue by their foreign key
	 * @param id_sla: SLA id
	 * @param name: SLO name
	 * @return a list of SLOValue objects with SLO name in the SLA with id id_sla 
	 * @throws ClassNotFoundException
	 */

	public HashSet<SLOValue> getValuesbyForeignKey(int id_sla, String name) throws ClassNotFoundException{
	       Class.forName("com.mysql.jdbc.Driver");
	  	   
	  	   try {
			Connection cn= DriverManager.getConnection("jdbc:mysql://localhost/sla?user=root&password=");
			Statement st=cn.createStatement();
			String sql="SELECT * FROM slo_value WHERE id_SLA='"+id_sla+"' AND name='"+name+"'";
			ResultSet rs=st.executeQuery(sql);
			HashSet<SLOValue> h=new HashSet<SLOValue>();
			while(rs.next()){
				String value=rs.getString("value");
				String valuetime=rs.getString("valuetime");
				String operator=rs.getString("operator");
				String unit=rs.getString("unit");
				String service=rs.getString("value_service");
				DefinitionDB dd=new DefinitionDB();
				Definition d=dd.getDefbyKey(id_sla,service,rs.getString("def_name"));
				SLOValue snew=new SLOValue(valuetime,value,operator,unit,service,d);
				h.add(snew);
			}
		return h;
	}
	  	 catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();return null;
			}
	}
}
