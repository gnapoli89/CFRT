import gate.util.GateException;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.sql.SQLException;
import java.util.ArrayList;
import logs.ObjectHolder;
import matching.AttackCheckerController;
import matching.Matching;
import storage.SlaDB;
import utilities.DialogUtility;
import GATE.Gate_main;
import GATE.SLA;

public class Main_system {

	
	
	public static void main() throws ClassNotFoundException, SQLException, GateException, IOException {
			
		
		File fileDir = new File("conf_file.txt");
		BufferedReader textreader=null;;
		try {
			textreader = new BufferedReader(
					   new InputStreamReader(
			                      new FileInputStream(fileDir), "UTF-8"));
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			String message="Configuration file not present!!";
			(new Thread(new DialogUtility(message))).start();
			e.printStackTrace();
		}
		String line="";
		String input="";
		int gate_used=-1;
		try {
			while((line=textreader.readLine())!= null){
				input+=line+"\n";
				int indexused=line.indexOf("GATE_used=");
				if(indexused>=0){
					String[] gate_used_line=line.split("GATE_used=");
					gate_used=Integer.parseInt(gate_used_line[1]);
					if(gate_used==0){
						System.out.println("GATE running...");
						Gate_main.gate_run();
						FileOutputStream fw=new FileOutputStream("conf_file.txt");
						input=input.replace("GATE_used=0","GATE_used=1");
						fw.write(input.getBytes());
						fw.close();
					}
				}
			}
			textreader.close();
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		
		ObjectHolder.init();
		SlaDB s=new SlaDB();
		ArrayList <SLA> listSLA=s.getAllSLA();
		
	
		
		System.out.println("Analyzing logs...");
		for(int i=0;i<listSLA.size();i++){
			new Thread(new Matching(listSLA.get(i))).start();
			new Thread(new AttackCheckerController(listSLA.get(i))).start();
		}
		
		
	}
}
