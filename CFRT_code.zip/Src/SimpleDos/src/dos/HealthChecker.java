package dos;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;



public class HealthChecker implements Runnable{

	private String server;
	private int port;
	private String uri;

	public HealthChecker(String server, int port, String uri) {
		this.server = server;
		this.port = port;
		this.uri = uri;
	}

	@Override
	public void run() {
		String targetURL;
		ProcessBuilder pb;
		Process p;


		try {
			String file = Test.HASHMAPS.getFilesToPut().get(0);
			targetURL = this.server+":"+this.port+"/"+this.uri+"/"+file+"?atk="+Test.ATTACKER_VAR; //build the URL
			//put test file
				Logger.write("putting test file (file1)");
				pb = new ProcessBuilder("curl", "--data", "@"+file, "--request", "PUT", targetURL);
				pb.redirectErrorStream(true);
				pb.start();
				Test.HASHMAPS.getFilesToGet().put(0, file);
			} catch (IOException e) {
				e.printStackTrace();
			}


			while(true){
				targetURL = this.server+":"+this.port+"/"+this.uri+"/"+Test.TEST_FILE; //build the URL
				HttpURLConnection con = null;
				URL obj = null;
				// optional default is GET
				try {
					obj = new URL(targetURL);
					con = (HttpURLConnection) obj.openConnection();
					con.setConnectTimeout(30000);
					con.setRequestMethod("GET");
										
					int responseCode = con.getResponseCode();
					System.out.println("\nSending 'GET' request to URL : " + targetURL);
					System.out.println("Response Code : " + responseCode);
					System.out.println("timeout : " + con.getConnectTimeout());

					if(responseCode == 200){
						Logger.write("Server status: OK");
					}else if(responseCode == 404){
						Logger.write("---404 FILE NOT FOUND---");
					}else if(responseCode == 500){
						Logger.write("Server status: BAD");
						Logger.write("RIAVVIO!");
						Runtime.getRuntime().exec(Test.TOMCAT_BASE_PATH+"/bin/shutdown.sh");
						Thread.sleep(10000);
						Runtime.getRuntime().exec(Test.TOMCAT_BASE_PATH+"/bin/startup.sh");
					}else {
						Logger.write("response code error: "+responseCode);
						Logger.write("---STOPPING HEALTH CHECKER---");
						return;
					}

				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					Logger.write("---RESTARTING ERROR...re-try---");
					try {
						Logger.write("---RE-RESTARTING---");
						Runtime.getRuntime().exec(Test.TOMCAT_BASE_PATH+"/bin/shutdown.sh");
						Thread.sleep(10000);
						Runtime.getRuntime().exec(Test.TOMCAT_BASE_PATH+"/bin/startup.sh");
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						Logger.write("---RESTARTING ERROR---");
						e1.printStackTrace();
						return;
					} catch (InterruptedException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}

				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}finally{
					try {
						Logger.write("health check in 10 secs...");
						con.disconnect();
						Thread.sleep(10000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} //healthcheck every min
				}
			}
		}
	}
