import gate.util.GateException;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Window;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.GridLayout;

import javax.swing.JTextField;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JButton;
import javax.swing.AbstractAction;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.sql.SQLException;

import javax.swing.Action;


public class MainFrame extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;

	/**
	 * Launch the application.
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 * @throws GateException 
	 */
	public static void main(String[] args) throws ClassNotFoundException, SQLException, GateException {
		File fileDir = new File("conf_file.txt");
		BufferedReader textreader;
		FileOutputStream fw;
		try {
			textreader = new BufferedReader(
					new InputStreamReader(
							new FileInputStream(fileDir), "UTF-8"));
			String line="";
			while((line=textreader.readLine())!= null){
				int indexhome=line.indexOf("GATE_home=");
				if(indexhome>=0){
					String[] gate_home_line=line.split("GATE_home=");
					if(gate_home_line.length<1){
						EventQueue.invokeLater(new Runnable() {
							public void run() {
								try {
									MainFrame frame = new MainFrame();
									frame.setVisible(true);
								} catch (Exception e) {
									e.printStackTrace();
								}
							}
						});
					}
					else{
						Main_system.main();
					}

				}
            }
		}
		catch (IOException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();}
		}
			/**
			 * Create the frame.
			 */
			public MainFrame() {
				setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				setBounds(100, 100, 450, 300);
				contentPane = new JPanel();
				contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
				contentPane.setLayout(new BorderLayout(0, 0));
				setContentPane(contentPane);

				JPanel panel = new JPanel();
				contentPane.add(panel, BorderLayout.CENTER);
				panel.setLayout(null);

				textField = new JTextField();
				textField.setBounds(127, 17, 150, 20);
				panel.add(textField);
				textField.setColumns(10);

				textField_1 = new JTextField();
				textField_1.setBounds(127, 74, 150, 20);
				panel.add(textField_1);
				textField_1.setColumns(10);

				JLabel lblGatemain = new JLabel("GATE_main");
				lblGatemain.setFont(new Font("Tahoma", Font.PLAIN, 15));
				lblGatemain.setBounds(10, 14, 86, 23);
				panel.add(lblGatemain);

				JLabel lblGateapp = new JLabel("GATE_app");
				lblGateapp.setFont(new Font("Tahoma", Font.PLAIN, 15));
				lblGateapp.setBounds(10, 77, 74, 17);
				panel.add(lblGateapp);

				textField_2 = new JTextField();
				textField_2.setColumns(10);
				textField_2.setBounds(127, 128, 150, 20);
				panel.add(textField_2);

				JLabel lblSlafile = new JLabel("SLA_file");
				lblSlafile.setFont(new Font("Tahoma", Font.PLAIN, 15));
				lblSlafile.setBounds(10, 128, 74, 17);
				panel.add(lblSlafile);

				textField_3 = new JTextField();
				textField_3.setColumns(10);
				textField_3.setBounds(127, 176, 150, 20);
				panel.add(textField_3);

				JLabel lblLogsfile = new JLabel("Log_file");
				lblLogsfile.setFont(new Font("Tahoma", Font.PLAIN, 15));
				lblLogsfile.setBounds(10, 176, 74, 17);
				panel.add(lblLogsfile);

				JButton btnExplore = new JButton("Explore...");
				btnExplore.setBounds(300, 16, 89, 23);
				panel.add(btnExplore);
				btnExplore.addActionListener(new FolderChooser());

				JButton button = new JButton("Explore...");
				button.setBounds(300, 73, 89, 23);
				panel.add(button);
				button.addActionListener(new FileChooser(textField_1,"Choose GATE app"));

				JButton button_1 = new JButton("Explore...");
				button_1.setBounds(300, 127, 89, 23);
				panel.add(button_1);
				button_1.addActionListener(new FileChooser(textField_2,"Choose SLA file"));

				JButton button_2 = new JButton("Explore...");
				button_2.setBounds(300, 175, 89, 23);
				panel.add(button_2);
				button_2.addActionListener(new FileChooser(textField_3,"Choose log file"));

				JButton btnStart = new JButton("OK");
				btnStart.setBounds(171, 217, 89, 23);
				panel.add(btnStart);
				btnStart.addActionListener(new StartSystem());
			}
			private class FolderChooser implements ActionListener {

				public void actionPerformed(ActionEvent e) {
					JFileChooser chooser=new JFileChooser();

					chooser.setCurrentDirectory(new java.io.File("."));
					chooser.setDialogTitle("Choose GATE directory");
					chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
					chooser.setAcceptAllFileFilterUsed(false);
					if (chooser.showOpenDialog(MainFrame.this) == JFileChooser.APPROVE_OPTION) { 
						textField.setText(chooser.getSelectedFile().getPath());
					}
				}
			}

			private class FileChooser implements ActionListener {
				private JTextField out;
				private String dialog_title;
				public FileChooser(JTextField out, String dialog_title){
					this.out=out;
					this.dialog_title=dialog_title;
				}
				public void actionPerformed(ActionEvent e) {
					JFileChooser chooser=new JFileChooser();

					chooser.setCurrentDirectory(new java.io.File("."));
					chooser.setDialogTitle(dialog_title);
					chooser.setAcceptAllFileFilterUsed(false);
					if (chooser.showOpenDialog(MainFrame.this) == JFileChooser.APPROVE_OPTION) { 
						out.setText(chooser.getSelectedFile().getPath());
					}	

				}
			}


			private class StartSystem implements ActionListener{


				public void actionPerformed(ActionEvent e) {
					File fileDir = new File("conf_file.txt");
					BufferedReader textreader;
					FileOutputStream fw;
					try {
						textreader = new BufferedReader(
								new InputStreamReader(
										new FileInputStream(fileDir), "UTF-8"));
						
						String line="";
						String input="";
						while((line=textreader.readLine())!= null){
							input+=line+"\n";
							int indexhome=line.indexOf("GATE_home=");
							if(indexhome>=0){
								String toReplace=textField.getText();
								if(System.getProperty("os.name").contains("Windows")){
									toReplace.replaceAll("/", "//");
								}
								input=input.replace("GATE_home=","GATE_home="+toReplace);
								

							}
							int indexapp=line.indexOf("GATE_app=");
							if(indexapp>=0){
								String toReplace=textField_1.getText();
								if(System.getProperty("os.name").contains("Windows")){
									toReplace.replaceAll("/", "//");
								}
								input=input.replace("GATE_app=","GATE_app="+toReplace);
							}
							int indexsla=line.indexOf("SLA_file=");
							if(indexsla>=0){
								input=input.replace("SLA_file=","SLA_file=file:"+textField_2.getText());
							}
							int indexlogs=line.indexOf("Logs_file=");
							if(indexlogs>=0){
								String toReplace=textField_3.getText();
								if(System.getProperty("os.name").contains("Windows")){
									toReplace.replaceAll("/", "//");
								}
								input=input.replace("Logs_file=","Logs_file="+toReplace);	
							}
						}
						fw=new FileOutputStream("conf_file.txt");
						fw.write(input.getBytes());
						fw.close();
						((JFrame)((JButton)e.getSource()).getRootPane().getTopLevelAncestor()).dispose();
						Main_system.main();
						
					} catch (UnsupportedEncodingException | FileNotFoundException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					} catch (IOException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					} catch (ClassNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (GateException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}



				}
            

			}

		}

