package matching;

/** Interface for an AttackChecker. When a new attack is implemented must extend this interface
 * 
 * @author 
 *
 *
 */

public interface AttackChecker extends Runnable {
	
	/**
	 *  sleeps for the maximum period and notify to user an eventual attack 
	 */
	public void run();
	/**
	 * controls information from violation db and checks if there is the attack 
	 * @return true: if all the violations are checked
	 *         false: otherwise
	 */
	public boolean checkAttack();

}
