package matching;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import net.sourceforge.jeval.EvaluationException;
import net.sourceforge.jeval.Evaluator;
import utilities.DialogUtility;

import logs.ObjectHolder;
import com.mongodb.BasicDBObject;

import GATE.Definition;
import GATE.SLO;
import GATE.SLOValue;

/** Calculates, inserts into MongoDB data collection Hourly, Daily and Monthly Uptime Percentage (HUP,DUP,MUP) values.
 *  Matches MUP values and HUP values (only to find an attack)
 * 
 * 
 *
 */

public class UptimeMatcher implements SLOMatcher{
	SLOValue sloValue;
	SLO slo;

	/**
	 ** @param slo SLO object Uptime
	 * @param v A MUP SloValue
	 */
	public UptimeMatcher(SLO slo, SLOValue v){
		sloValue = v;
		this.slo = slo;
	}

	/**
	 * calculates HUP value every hour, stores it into MongoDB data collection and aggregates them to calculate DUP and MUP values (stored
	 * into data collection too). 
	 * 
	 */
	public void run() {
		Definition d = sloValue.getslovaluedef();
		String form = d.getForm();
		String period = d.getPeriod();
		String valuetime = d.getValuetime();
		String unit=d.getUnit();
		Boolean flag = true;


		Double[] hourlyValues=new Double[24];
		Double[] dailyValues=new Double[3];
		int numberHours=0;
		int numberDays=0;
		Double monthlyUptime;

		//monthly uptime
		//Calculator monthlyUptime = new Calculator(period, valuetime,form);
		//daily uptime
		int dailyValuetime = (Integer.parseInt(valuetime)/30);
		//Calculator dailyUptime = new Calculator(period, Integer.toString(dailyValuetime),form);
		//hourly uptime
		int hourlyValuetime = dailyValuetime/24;
		
		Calculator hourlyUptime = new Calculator(period, Integer.toString(hourlyValuetime),form,unit, slo.getName());
		ExecutorService e = Executors.newFixedThreadPool(1);

		while(flag || numberHours<24){
			Future<Double> hourlyResult= e.submit(hourlyUptime);
			try {
				Double result=hourlyResult.get();
				hourlyValues[numberHours]=result;
				numberHours++;
				System.out.println("numberHours="+numberHours);
				BasicDBObject hup=new BasicDBObject("Type", "hourly_uptime_percentage")
											.append("Value", result)
											.append("Time", ObjectHolder.timeSup[0]);
				ObjectHolder.dbdata.insertObject(hup);
				matchSLAValue(sloValue, result, "hourlyUptimePercentage"); //launch matching method but stores only the violation without notify
				//System.out.println(ObjectHolder.dbdata.getMax("Time").toString());
				if(numberHours==hourlyValues.length){
					numberHours=0;
					Double hoursSum=0.0;
					for(int k=0;k<hourlyValues.length;k++){
						hoursSum+=hourlyValues[k];
					}
					dailyValues[numberDays]=hoursSum/(hourlyValues.length);
					numberDays++;
					System.out.println("numberDays="+numberDays);
					BasicDBObject dup=new BasicDBObject("Type", "daily_uptime_percentage")
												.append("Value", dailyValues[numberDays-1])
												.append("Time", ObjectHolder.timeSup[0]);
					ObjectHolder.dbdata.insertObject(dup);
					if(numberDays==dailyValues.length){
						numberDays=0;
						Double daysSum=0.0;
						for(int k=0;k<dailyValues.length;k++){
							daysSum+=dailyValues[k];
						}
						monthlyUptime=daysSum/(dailyValues.length);
						BasicDBObject mup=new BasicDBObject("Type", "montly_uptime_percentage")
													.append("Value", monthlyUptime)
													.append("Time", ObjectHolder.timeSup[0]);
						ObjectHolder.dbdata.insertObject(mup);
						matchSLAValue(sloValue,monthlyUptime,slo.getName());
					}

				}

			} catch (InterruptedException | ExecutionException e1) {
				if (e1.getCause() instanceof EvaluationException){
					System.out.println("Formula not supported. Impossible evaluation.");
					//show violation alert
					String message="Violation on "+slo.getName()+" formula not supported.";
					(new Thread(new DialogUtility(message))).start();
					//insert violation in DB
					BasicDBObject vio=new BasicDBObject("SLO", slo.getName())
											.append("Difference", "Formula not valid")
											.append("Unit", sloValue.getUnit())
											.append("Time",ObjectHolder.timeSup[0]); 
					ObjectHolder.dbviolations.insertObject(vio); 
					
					flag = false; //it stops calculate this SLO value
				}
				e1.printStackTrace();
			}

		}

	}

	/** 
	 * Matches every MUP calculated value with SLO one: if a violation is found notifies it to the user and stores it into
	 * MongoDB violation database
	 */

	public void matchSLAValue(SLOValue sloValue, Object realvalue,String sloName) {
		String value=sloValue.getValue();
		String operator=sloValue.getOperator();
		String formula=value+operator+realvalue;
		//System.out.println(formula);
		Evaluator e=new Evaluator();
		try {
			Double result=Double.valueOf(e.evaluate(formula));
			result=Math.round(result*100.00)/100.00;
			Double difference=(Double)realvalue-Double.valueOf(value);
			difference=Math.round(difference*100.00)/100.00;
			if(result==1.0){
				String message="Violation on "+sloName+"with difference of " +difference+sloValue.getUnit();
				if(!sloName.equalsIgnoreCase("hourlyUptimePercentage"))
				(new Thread(new DialogUtility(message))).start();
				BasicDBObject vio=new BasicDBObject("SLO", sloName)
										.append("Difference", difference)
										.append("Unit", sloValue.getUnit())
										.append("Time",ObjectHolder.timeSup[0]); 
				ObjectHolder.dbviolations.insertObject(vio); 
			} 	


		} catch (EvaluationException e1) {
			e1.printStackTrace();
		}


	}
}
