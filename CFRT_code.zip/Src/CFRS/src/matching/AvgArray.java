package matching;

import java.util.concurrent.Callable;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCursor;

import logs.AWSDictionary;
import logs.ObjectHolder;

/** Average function invoked if in an avg function other formulas are not present
 * 
 * 
 *
 */

public class AvgArray implements Callable<String> {

	private String formula;
	private double period;
	private long limInf;
	private long limSup;
	private String result;
    /** 
     ** @param formula formula into avg function
     * @param periodDouble SLO period expressed in double
     */
	public AvgArray(String formula, double periodDouble) {
		result="";
		this.formula=formula;
		period=periodDouble;
		limInf = ObjectHolder.timeInf[1];
		limSup = ObjectHolder.timeSup[1];
	}

	/**
	 * Calculates all the values of the formula in the SLO period
	 * 
	 *  @return: a string containing all the values separated by ;
	 */
	public String call() throws InterruptedException {
		int index=0;
		int index1=0;

		if(limInf < 0 || limSup < 0){
			//limInf = Calendar.getInstance().getTimeInMillis();
			ObjectHolder.timeInf[1] = limInf = Long.parseLong(ObjectHolder.db.getMin("Time").get("Time").toString());
			ObjectHolder.timeSup[1] = limSup = ObjectHolder.timeInf[1]+(int)period*60000;
		}else{
			ObjectHolder.timeInf[1] = limInf = limSup;
			ObjectHolder.timeSup[1] = limSup = limInf+(int)period*60000;
		}
		
		String atom;
		String newFormula = formula;
		while(index>=0){
			index=newFormula.indexOf("[",index+1);
			index1=newFormula.indexOf("]",index+1);
			if(index<0)
				break;
			atom = newFormula.substring(index+1,index1);
			atom = atom.trim();
			//System.out.println(atom);
			
			//set parameters of interval of time into Dictionary
			while(AWSDictionary.in_use){
				Thread.sleep(1000);
			}
			ObjectHolder.dictionary.setlimInf(limInf);
			ObjectHolder.dictionary.setlimSup(limSup);
			
			DBCursor cursor = ObjectHolder.db.find((BasicDBObject) ObjectHolder.dictionary.translate(atom));
			while(cursor.hasNext()){
				result=result+cursor.next().get("TurnAroundTime")+";";
			}
			//System.out.println(result);
		}
		return result;

	}
}
