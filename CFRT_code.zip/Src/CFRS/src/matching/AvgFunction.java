package matching;

import java.util.ArrayList;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import utilities.TimerTaskUtility;

import com.mongodb.BasicDBObject;

import logs.AWSDictionary;
import logs.ObjectHolder;
import net.sourceforge.jeval.EvaluationException;
import net.sourceforge.jeval.Evaluator;
import net.sourceforge.jeval.function.Function;
import net.sourceforge.jeval.function.FunctionConstants;
import net.sourceforge.jeval.function.FunctionException;
import net.sourceforge.jeval.function.FunctionResult;


/** JEval function for average. Launched when in SLO formula "avg(" is found
 * 
 * 
 *
 */
public class AvgFunction implements Function{
	ArrayList<String> list = new ArrayList<String>();

	@Override

	public String getName() {
		return "avg";
	}

    /** Calculates average value of the formula 
     *  @param evaluator: a JEval evaluator
     *  @param args: formula into avg with parameters
     *  @return a FunctionResult JEval object with calculation result
     */
	/* (non-Javadoc)
	 * @see net.sourceforge.jeval.function.Function#execute(net.sourceforge.jeval.Evaluator, java.lang.String)
	 */
	@Override
	public FunctionResult execute(Evaluator evaluator, String args) throws FunctionException {

		//System.out.println("argomenti di avg: "+args);

		String unit="null";
		String period="null";
		String valueTime="null";
		String sloName="null";
		String regex = "[']<(\\d+.\\d+)><(\\d+)><(.+)><(\\w+)>(.)*";
		Pattern pattern = Pattern.compile(regex);
		
		Matcher m = pattern.matcher(args);
		if (m.matches()) {	
			period = m.group(1);
			valueTime = m.group(2);
			unit=m.group(3);
			sloName = m.group(4);
			//clear the formula removing all parameters
			args = args.replaceAll("<(\\d+.\\d+)><(\\d+)><(.+)><(\\w+)>", "");
			//System.out.println("Sono in AVG; ho preso valuetime e period: "+args);
		}else{
			System.out.println(args+" not matches");
			//toDo implement Exception 
		}

		double periodDouble= Double.parseDouble(period);
		int numOfMinutesInt = Integer.parseInt(valueTime);

		ExecutorService e1=Executors.newFixedThreadPool(1);
		ExecutorService e2=Executors.newFixedThreadPool(1);
		TimerTaskUtility timer=new TimerTaskUtility((int)periodDouble*60000);
		Callable<String> mytask=null;
		String[] operators={"+","-","*","/","avg","count"}; //if you add a new function must be in this list
		int flag=0;
		//control if there's an operator inside avg or not.
		for(int i=0;i<operators.length;i++){
			if(args.contains(operators[i])){
				flag=1;
			    break;}
		}
		
		
		if(flag==1){
			mytask = new AvgSingleResult(evaluator,args,periodDouble,unit);
		}
		if(flag==0){
			mytask = new AvgArray(args,periodDouble);
		}

		while(list.size() < numOfMinutesInt/periodDouble){
			//starts timer
			Future<Long> timeRes = e2.submit(timer);
			//starts calculation
			Future<String> fresult = e1.submit(mytask);
			try {
				String result=fresult.get();
				list.add(result);
				timeRes.get();
			}catch (ExecutionException e) {
				e.printStackTrace();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		if(mytask instanceof AvgSingleResult){
			double sum=0.0;
			for(int i=0;i<list.size();i++){
				double num=Double.parseDouble(list.get(i));
				sum+=num;
			}
			double average=sum/(list.size());
			//System.out.println("Downtime Average: "+average);

			return new FunctionResult(Double.toString(average),FunctionConstants.FUNCTION_RESULT_TYPE_NUMERIC);

		}
		if(mytask instanceof AvgArray){
			String restimes=list.get(0);
			String[] results=restimes.split(";");
			Double sum=0.0;
			for(int i=0;i<results.length;i++){
				if(results[i] != ""){
				double num=Double.parseDouble(results[i]);
				sum+=num;
				}
			}
			double average=sum/(results.length);
			//System.out.println("Average Response Time: "+average);

			return new FunctionResult(Double.toString(average),FunctionConstants.FUNCTION_RESULT_TYPE_NUMERIC);
			
		}

		return null;
	}

}
