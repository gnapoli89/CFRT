package matching;

import GATE.SLO;
import GATE.SLOValue;

/** Interface for SLOMatcher. If a new SLO is added to system, his Matcher must extend this interface
 * 
 * 
 *
 */

public interface SLOMatcher extends Runnable {
	
	/**
	 * Instantiate a new Calculator and save the result returned from it into dbdata db. 
	 */
	public void run();
	
	/**
	 * Match the value calculated with SLO value and notify eventual violations
	 * @param sloValue value contained into SLOValue object
	 * @param realvalue value calculated with JEVAL
	 * @param sloName SLO name contained into SLO object 
	 */
	public void matchSLAValue(SLOValue sloValue, Object realvalue,String sloName);

}
