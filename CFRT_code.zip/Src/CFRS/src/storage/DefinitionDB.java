package storage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashSet;
import java.util.StringTokenizer;

import GATE.Definition;

/**
 * Class that manages table Definition in SLA database
 * 
 *
 */

public class DefinitionDB {

	public DefinitionDB(){}
	
	/** Add a new row to table Definition (or update one if already exists)
	 * 
	 * @param d: Definition to add
	 * @param provider: SLA provider
	 * @param service: SLA service
	 * @return the number of rows affected (1 if there are no errors)
	 * @throws ClassNotFoundException
	 */
	
	public int add(Definition d, String provider, String service)throws ClassNotFoundException{
	       Class.forName("com.mysql.jdbc.Driver");
	  	   
	  	   try {
			Connection cn= DriverManager.getConnection("jdbc:mysql://localhost/sla?user=root&password=");
			Statement st=cn.createStatement();
			SlaDB sd=new SlaDB();
			int id=sd.take_id_from_key(provider, service);
			String sql="SELECT * FROM definition WHERE id_SLA='"+id+"' AND name='"+d.getName()+"'"; //control if is new o it is an update
			ResultSet rs=st.executeQuery(sql);
			rs.last();
			int rows=rs.getRow();
			rs.beforeFirst();
			StringTokenizer permin=new StringTokenizer(d.getPeriod()," ");
			String period=permin.nextToken(); //take only the number without "minutes"
			String valuetime=d.getValuetime();
			String vtmin="";
			if(valuetime!=null){
				StringTokenizer perval=new StringTokenizer(valuetime," ");
				if(perval.countTokens()!=1){ //we have x minutes
					double value=Double.parseDouble(perval.nextToken());
					int valueint=(int) value;
					vtmin=Integer.toString(valueint);
				}
				else{
				
				
					if(valuetime.equals("month")){ //transforms valuetime in respective minutes
						vtmin="43200";
					}
					if(valuetime.equals("year")){
						vtmin="518400";
					}
					if(valuetime.equals("day")){
						vtmin="1440";
					}
					if(valuetime.equals("hour")){
						vtmin="60";
					}}}
			String form=d.getForm();
			form=form.replace("'", "''");
			if(rows!=0){
				sql="UPDATE definition SET id_SLA='"+id+"',name='"+d.getName()+"',form='"+form+"',period='"+period+"',valuetime='"+vtmin+"',unit='"+d.getUnit()+"' WHERE id_SLA='"+id+"' AND name='"+d.getName()+"'";
				return st.executeUpdate(sql);}	
	  	    
			sql="INSERT INTO definition (id_SLA,name,form,period,valuetime,unit) VALUES ('"+id+"','"+d.getName()+"','"+form+"','"+period+"','"+vtmin+"','"+d.getUnit()+"')";
			return st.executeUpdate(sql);
			
	  	   } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();return 0;
		}
	    }


	/**
	 * Return all the Definition objects in a SLA
	 * @param id : SLA id 
	 * @return the HashSet of all Definition objects in the SLA
	 * @throws ClassNotFoundException
	 */
	public HashSet<Definition> getDefbyId(int id) throws ClassNotFoundException{
	       Class.forName("com.mysql.jdbc.Driver");
	  	   
	  	   try {
			Connection cn= DriverManager.getConnection("jdbc:mysql://localhost/sla?user=root&password=");
			Statement st=cn.createStatement();
			String sql="SELECT * FROM definition WHERE id_SLA='"+id+"'";
			ResultSet rs=st.executeQuery(sql);
			HashSet<Definition> h=new HashSet<Definition>();
			while(rs.next()){
				String name=rs.getString("name");
				String form=rs.getString("form");
				String period=rs.getString("period");
				String valuetime=rs.getString("valuetime");
				String unit=rs.getString("unit");
				//String service=rs.getString("service");
				Definition ndef=new Definition(name,form,period,unit,valuetime);
				h.add(ndef);
				
			}
		return h;}
	  	 catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();return null;
			}
 }

	/**
	 * Return the Definition associated to its key
	 * @param id: SLA id
	 * @param service: service associated to definition
	 * @param definition name
	 * @return Definition object with this key
	 * @throws ClassNotFoundException
	 */
	public Definition getDefbyKey(int id, String name)throws ClassNotFoundException{
	       Class.forName("com.mysql.jdbc.Driver");
	  	   
	  	   try {
			Connection cn= DriverManager.getConnection("jdbc:mysql://localhost/sla?user=root&password=");
			Statement st=cn.createStatement();
			String sql="SELECT * FROM definition WHERE id_SLA='"+id+"' AND name ='"+name+"'";
			ResultSet rs=st.executeQuery(sql);
			rs.next();
			String form=rs.getString("form");
			String period=rs.getString("period");
			String valuetime=rs.getString("valuetime");
			String unit=rs.getString("unit");
			return new Definition(name,form,period,unit,valuetime);
		
	}
		  	 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();return null;
				}
	}
}
