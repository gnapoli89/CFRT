package storage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashSet;

import GATE.SLO;
import GATE.SLOValue;
/**
 * Class that manages table SLO in SLA database 
 * 
 *
 */
public class SloDB {
	
	public SloDB(){
		
	}
	
	/**
	 * Add a new SLO to SLO table
	 * @param s: SLO to add
	 * @param provider: SLA provider
	 * @param service: SLA service
	 * @return the number of rows affected (1 if there are no errors)
	 * @throws ClassNotFoundException
	 */
	public int add(SLO s, String provider, String service)throws ClassNotFoundException{
	       Class.forName("com.mysql.jdbc.Driver");
	  	   
	  	   try {
			Connection cn= DriverManager.getConnection("jdbc:mysql://localhost/sla?user=root&password=");
			Statement st=cn.createStatement();
			SlaDB sd=new SlaDB();
			int id=sd.take_id_from_key(provider, service);
	  	    String sql="INSERT INTO slo (name,id_SLA) VALUES ('"+s.getName()+"','"+id+"')";
	  	    return st.executeUpdate(sql);
	  	   } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();return 0;
		}
	    
	}

	/**
	 * Take all the SLO present in a SLA with id sla_id 
	 * @param sla_id: SLA id
	 * @return a set of SLO present in the SLA with id sla_id
	 * @throws ClassNotFoundException
	 */
	public HashSet<SLO> getSLObyId(int sla_id)throws ClassNotFoundException{
	       Class.forName("com.mysql.jdbc.Driver");
	  	   
	  	   try {
			Connection cn= DriverManager.getConnection("jdbc:mysql://localhost/sla?user=root&password=");
			Statement st=cn.createStatement();
			String sql="SELECT * FROM slo WHERE id_sla='"+sla_id+"'";
			ResultSet rs=st.executeQuery(sql);
			HashSet<SLO> h=new HashSet<SLO>();
			while(rs.next()){
				String name=rs.getString("name");
				SloValueDB s=new SloValueDB();  
				HashSet<SLOValue> val=s.getValuesbyForeignKey(sla_id,name);
				SLO newSlo=new SLO(name,val);
			    h.add(newSlo);
			}
		return h;
	}
	  	 catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();return null;
			}
	}
}
