package logs;
import com.mongodb.*;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.text.DateFormat;
import java.text.FieldPosition;
import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import utilities.DialogUtility;
import utilities.TrainSetUtility;

public class ObjectHolder {
	
	public static DBManager db = new DBManager();
	public static DBManager dbdata=new DBManager();
	public static DBManager dbviolations=new DBManager();
	public static DBManager dbattacks=new DBManager();
	public static AWSDictionary<String, String> dictionary = new AWSDictionary<String, String>();
	public static TrainSetUtility train=new TrainSetUtility();
	
	//add a -1 each time a new slo is implemented 
	public static long[] timeInf = new long[]{-1, -1, -1};
	public static long[] timeSup = new long[]{-1, -1, -1};
	
	
	public static void init() throws IOException{
		File fileDir = new File("conf_file.txt");
		BufferedReader textreader = new BufferedReader(
				   new InputStreamReader(
		                      new FileInputStream(fileDir), "UTF-8"));
		String line="";
		String home_logs="";
		try{
		while((line=textreader.readLine())!= null){
			int indexlogs=line.indexOf("Logs_file=");
			if(indexlogs>=0){
				String[] home_logs_line=line.split("Logs_file=");
				home_logs=home_logs_line[1];
			}
			
		}
		}
		catch(ArrayIndexOutOfBoundsException e){
			String message="Parameter logs_file is empty: please restart FRS and insert it";
			(new Thread(new DialogUtility(message))).start();
		}
 		textreader.close();
		db.setDatabase("test");
		db.setCollection("log");
		dbdata.setDatabase("test");
		dbdata.setCollection("data");
		dbviolations.setDatabase("test");
		dbviolations.setCollection("violations");
		dbattacks.setDatabase("test");
		dbattacks.setCollection("attacks");
		DBObject minTime = db.getMin("Time");
		if(minTime == null){
			System.out.println("Loading...");
			db.LoadDB(home_logs);
			System.out.println("Done!");
		}
		//set-up all variabiles
		//AWSDictionary<String, String> dictionary = new AWSDictionary<String, String>();
		//dictionary.setlimInf(0);
		//dictionary.setlimSup(Long.parseLong("1424370957000"));
		
		//DBObject query = dictionary.translate("Internal Error or Service Unavailable"); 
		//System.out.println(db.count(query));	
	}
}
