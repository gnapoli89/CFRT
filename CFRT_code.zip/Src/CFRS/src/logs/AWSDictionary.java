package logs;
import java.util.Dictionary;
import java.util.Hashtable;

import com.mongodb.DBObject;
import com.mongodb.util.JSON;


public class AWSDictionary <K,V> {
	
	public static Dictionary<String, String> dictionary = new Hashtable<String,String>();
	public static boolean in_use=false;
	private long limInf;
	private long limSup;
	
	public AWSDictionary(){
		dictionary.put("error � InternalError � or � ServiceUnavailable �", "{ $and : [ {$or: [{ErrorCode : \"InternalError\"}, {ErrorCode : \"ServiceUnavailable\"}]}, {$and : [{Time: {$gte : "+limInf+"}}, {Time:{$lte : "+limSup+"}} ] } ] }");
		dictionary.put("total number of requests", "{ $and : [{Time : {$gte : "+limInf+"}}, {Time:{$lte :"+limSup+"}}]}");
		dictionary.put("of all requests response times", "{ $and : [{Time : {$gte : "+limInf+"}}, {Time:{$lte :"+limSup+"}}]}");
		dictionary.put("separate cloud service customer users", "{ $and : [{Time : {$gte : "+limInf+"}}, {Time:{$lte :"+limSup+"}}]}");
	}
	
	private void refreshValues(){
		dictionary.put("error � InternalError � or � ServiceUnavailable �", "{ $and : [ {$or: [{ErrorCode : \"InternalError\"}, {ErrorCode : \"ServiceUnavailable\"}]}, {$and : [{Time: {$gte : "+limInf+"}}, {Time:{$lte : "+limSup+"}} ] } ] }");
		dictionary.put("total number of requests", "{ $and : [{Time : {$gte : "+limInf+"}}, {Time:{$lte :"+limSup+"}}]}");
		dictionary.put("of all requests response times", "{ $and : [{Time : {$gte : "+limInf+"}}, {Time:{$lte :"+limSup+"}}]}");
		dictionary.put("separate cloud service customer users", "{ $and : [{Time : {$gte : "+limInf+"}}, {Time:{$lte :"+limSup+"}}]}");
	}
	
	public void setlimInf(long x){
		in_use=true;
		limInf=x;
		this.refreshValues();
	}
	public long getlimInf(){
		return limInf;
	}
	public void setlimSup(long x){
		in_use=true;
		limSup=x;
		this.refreshValues();
	}
	
	public long getlimSup(){
		return limSup;
	}

	public DBObject translate(String string) {
		DBObject toReturn=(DBObject) JSON.parse(dictionary.get(string));
	    in_use=false;
		return toReturn;
	}

}
